extends SceneTree
## Integración de combate, ataques a aves, protección y finales de ronda.
var failures: int = 0
var farm: Node
var player: FarmerPlayer
var combat: Node
var gm: Node
const BIRD: PackedScene = preload("res://scenes/entities/chicken.tscn")
const FOX: PackedScene = preload("res://scenes/entities/fox.tscn")
const EAGLE: PackedScene = preload("res://scenes/entities/eagle.tscn")
const CROW: PackedScene = preload("res://scenes/entities/scarecrow.tscn")
const TRAP: PackedScene = preload("res://scenes/entities/trap.tscn")

func _initialize() -> void:
    call_deferred("_run")

func frames(count: int) -> void:
    for i in range(count):
        await physics_frame

func check(condition: bool, message: String) -> void:
    if condition:
        print("PASS: " + message)
    else:
        failures += 1
        push_error("FAIL: " + message)

func new_round(config: LevelData = null) -> void:
    paused = false
    if is_instance_valid(farm):
        farm.queue_free()
        await frames(3)
    farm = load("res://scenes/levels/farm.tscn").instantiate()
    if config != null:
        farm.level_data = config
    root.add_child(farm)
    current_scene = farm
    farm.get_node("ThreatDirector").enabled = false
    player = farm.get_node("Depth/Player")
    combat = player.get_node("PlayerCombat")
    gm = root.get_node("GameManager")
    for bird in get_nodes_in_group("chickens"):
        bird.queue_free()
    await frames(4)
    player.position = Vector2(608,432)
    player.velocity = Vector2.ZERO

func spawn_bird(point: Vector2, frozen: bool = true) -> FarmChicken:
    var bird: FarmChicken = BIRD.instantiate()
    bird.data = load("res://resources/chickens/standard.tres")
    bird.position = point
    bird.lost.connect(func(data: ChickenData, _cause: StringName) -> void: root.get_node("EventBus").chicken_lost.emit(data.reward))
    farm.get_node("Depth").add_child(bird)
    bird.set_physics_process(not frozen)
    return bird

func spawn_fox(point: Vector2, frozen: bool = false) -> FarmFox:
    var fox: FarmFox = FOX.instantiate()
    fox.position = point
    farm.get_node("Depth").add_child(fox)
    fox.set_physics_process(not frozen)
    return fox

func spawn_eagle(point: Vector2, frozen: bool = false) -> FarmEagle:
    var eagle: FarmEagle = EAGLE.instantiate()
    eagle.position = point
    farm.get_node("Depth").add_child(eagle)
    eagle.set_physics_process(not frozen)
    return eagle

func wall_at(point: Vector2) -> Node:
    var wall := StaticBody2D.new()
    wall.collision_layer = 8
    var shape := CollisionShape2D.new()
    var rectangle := RectangleShape2D.new()
    rectangle.size = Vector2(4,60)
    shape.shape = rectangle
    wall.position = point
    wall.add_child(shape)
    farm.add_child(wall)
    return wall

func _run() -> void:
    await new_round()
    check(player.health == 5 and gm.health == 5, "Ronda comienza con cinco corazones")
    check(combat.ammunition == gm.current_level.ammunition, "Munición inicial procede de LevelData")
    check(combat.scarecrows == 2, "Dos espantapájaros disponibles")
    check(player.take_damage(1), "Impacto válido resta vida")
    check(player.health == 4 and gm.health == 4, "Vida local y HUD/estado global sincronizados")
    check(not player.take_damage(1) and player.health == 4, "Invulnerabilidad evita daño por cada frame de contacto")
    await frames(85)
    player.is_airborne = true
    check(not player.take_damage(1), "Salto esquiva daño de contacto")
    player.is_airborne = false
    var fox: FarmFox = spawn_fox(Vector2(616,432))
    await frames(4)
    check(player.health == 3, "Contacto de zorro daña al granjero")
    fox.queue_free()
    await frames(85)
    # Proyectiles reales: límite de munición, cono, alcance, paredes y no fuego amigo.
    player.facing = Vector2.RIGHT
    fox = spawn_fox(Vector2(690,432), true)
    var friendly: FarmChicken = spawn_bird(Vector2(650,432))
    var start_ammo: int = combat.ammunition
    check(combat.shoot(), "F dispara una carga de escopeta")
    check(combat.ammunition == start_ammo-1, "Tres perdigones consumen una sola carga")
    check(not combat.shoot(), "Enfriamiento impide doble disparo inmediato")
    await frames(20)
    check(not is_instance_valid(fox), "Perdigón elimina/espanta al zorro alcanzado")
    check(is_instance_valid(friendly) and not friendly.is_claimed, "Disparos no dañan a los pollos")
    friendly.queue_free()
    await frames(30)
    fox = spawn_fox(Vector2(820,432), true)
    combat.shoot()
    await frames(45)
    check(is_instance_valid(fox), "Escopeta no alcanza enemigos fuera de 150 px")
    fox.queue_free()
    await frames(5)
    fox = spawn_fox(Vector2(690,432), true)
    var wall: Node = wall_at(Vector2(655,432))
    await frames(3)
    combat.shoot()
    await frames(45)
    check(is_instance_valid(fox), "Pared detiene los perdigones")
    wall.queue_free()
    fox.queue_free()
    combat.ammunition = 0
    check(not combat.shoot(), "Sin munición no se dispara")
    await frames(5)
    # Un zorro no puede robar a través de un muro, incluso a distancia corta.
    var shielded: FarmChicken = spawn_bird(Vector2(638,432))
    fox = spawn_fox(Vector2(622,432))
    wall = wall_at(Vector2(630,432))
    await frames(12)
    check(is_instance_valid(shielded) and not shielded.is_claimed, "Zorro no roba a través de paredes")
    shielded.queue_free()
    fox.queue_free()
    wall.queue_free()
    await frames(4)
    # Zorro roba una única ave y abandona la escena.
    var prey: FarmChicken = spawn_bird(Vector2(830,390))
    fox = spawn_fox(Vector2(820,390))
    var before: int = gm.lost_chickens
    await frames(8)
    check(not is_instance_valid(prey) and gm.lost_chickens == before+1, "Zorro roba un ave y registra una pérdida")
    check(not is_instance_valid(fox), "Zorro se retira tras el robo")
    await frames(8)
    check(gm.lost_chickens == before+1, "Robo no se registra dos veces")
    # Pérdida de un ave en carnada limpia también la trampa.
    var trap: BaitTrap = TRAP.instantiate()
    trap.position = Vector2(830,390)
    farm.get_node("Depth").add_child(trap)
    prey = spawn_bird(trap.position)
    await frames(6)
    check(prey.is_trapped(), "Ave de prueba queda retenida por carnada")
    fox = spawn_fox(Vector2(820,390))
    await frames(8)
    check(not is_instance_valid(trap) and not is_instance_valid(prey), "Zorro puede robar un ave retenida y consume la trampa")
    # Aviso aéreo y ventana de vulnerabilidad.
    prey = spawn_bird(Vector2(820,390))
    var eagle: FarmEagle = spawn_eagle(Vector2(820,390))
    check(eagle.begin_warning(prey), "Águila inicia aviso en una zona sin protección")
    await frames(4)
    check(eagle.state == FarmEagle.State.WARNING and eagle.get_node("Shadow").visible, "Sombra visible antes del descenso")
    check(not eagle.receive_shot(), "Águila invulnerable durante aviso/vuelo alto")
    await frames(83)
    check(eagle.state == FarmEagle.State.DIVE, "Aviso pasa a picada")
    check(eagle.receive_shot(), "Águila vulnerable durante el descenso")
    await frames(4)
    check(not is_instance_valid(eagle) and is_instance_valid(prey), "Derribar águila antes del impacto salva al ave")
    prey.queue_free()
    # Picada sin defensa roba y cuenta una sola vez.
    prey = spawn_bird(Vector2(820,390))
    eagle = spawn_eagle(Vector2(820,390))
    eagle.begin_warning(prey)
    before = gm.lost_chickens
    await frames(130)
    check(not is_instance_valid(prey) and gm.lost_chickens == before+1, "Picada sin defensa roba el ave objetivo")
    await frames(50)
    check(gm.lost_chickens == before+1, "Picada no duplica pérdida")
    # Proyectil real contra un águila en picada, no solo llamada directa al método.
    player.position = Vector2(760,390)
    player.facing = Vector2.RIGHT
    combat.ammunition = 3
    await frames(45)
    prey = spawn_bird(Vector2(820,390))
    eagle = spawn_eagle(prey.position)
    eagle.begin_warning(prey)
    await frames(87)
    check(combat.shoot(), "Disparo real durante la ventana de picada")
    await frames(16)
    check(not is_instance_valid(eagle) and is_instance_valid(prey), "Perdigones reales derriban águila descendiendo")
    prey.queue_free()
    # El seguimiento de picada alcanza aves móviles, no solo objetivos inmóviles.
    player.position = Vector2(608,432)
    prey = spawn_bird(Vector2(820,390), false)
    eagle = spawn_eagle(prey.position)
    eagle.begin_warning(prey)
    before = gm.lost_chickens
    await frames(145)
    check(not is_instance_valid(prey) and gm.lost_chickens == before+1, "Picada rápida puede alcanzar un ave que huye")
    await frames(45)
    # Protección de espantapájaros y cancelación de ataque ya anunciado.
    player.position = Vector2(608,432)
    player.facing = Vector2.RIGHT
    var crow: FarmScarecrow = combat.place_scarecrow()
    check(crow != null and combat.scarecrows == 1, "R coloca espantapájaros y consume suministro")
    check(crow.protects(Vector2(700,432)) and not crow.protects(Vector2(900,432)), "Radio de protección distingue dentro y fuera")
    prey = spawn_bird(Vector2(700,432))
    eagle = spawn_eagle(Vector2(700,432))
    check(not eagle.begin_warning(prey), "Águila no inicia picada dentro del radio seguro")
    eagle.queue_free()
    prey.queue_free()
    await frames(4)
    player.position = Vector2(832,420)
    player.facing = Vector2.DOWN
    check(combat.place_scarecrow() == null and combat.scarecrows == 1, "No colocar espantapájaros sobre agua ni gastar suministro")
    player.position = Vector2(900,390)
    player.facing = Vector2.RIGHT
    prey = spawn_bird(Vector2(936,390))
    eagle = spawn_eagle(prey.position)
    check(eagle.begin_warning(prey), "Segundo objetivo sin protección admite aviso")
    var second_crow: FarmScarecrow = combat.place_scarecrow()
    await frames(4)
    check(second_crow != null and eagle.state == FarmEagle.State.RETREAT, "Colocar protección durante aviso cancela la picada")
    check(combat.scarecrows == 0 and combat.place_scarecrow() == null, "No exceder suministro de espantapájaros")
    prey.queue_free()
    # Oleadas en manada/parvada y límites de población.
    var director: Node = farm.get_node("ThreatDirector")
    var foxes: int = director.spawn_fox_wave(20)
    var eagles: int = director.spawn_eagle_wave(20)
    check(foxes == gm.current_level.max_foxes, "Spawner limita población de zorros")
    check(get_nodes_in_group("eagles").size() <= gm.current_level.max_eagles, "Spawner limita población de águilas")
    check(eagles > 1 and foxes > 1, "Oleadas permiten manadas y parvadas")
    # Resultados: usar escenas nuevas para resetear entidades, suministros y señales.
    await new_round()
    var data: LevelData = gm.current_level.duplicate()
    data.goal_mode = LevelData.GoalMode.BIRDS
    data.bird_quota = 2
    await new_round(data)
    gm._on_deposited(2,20)
    check(gm.state == gm.RoundState.FINISHED and gm.won_round, "Victoria al depositar la cuota de aves")
    check(paused and farm.get_node("ResultOverlay/Panel").visible, "Final pausa el mundo y muestra resumen")
    check("Aves salvadas: 2" in farm.get_node("ResultOverlay/Panel/Summary").text, "Resumen contiene contadores reales")
    gm._on_lost(100)
    check(gm.won_round and gm.lost_chickens == 0, "Eventos tardíos no cambian resultado cerrado")
    # Reintentar por botón real debe desbloquear física y reconstruir la escena.
    farm.get_node("ResultOverlay/Panel/Retry").pressed.emit()
    await frames(8)
    farm = current_scene
    player = farm.get_node("Depth/Player")
    combat = player.get_node("PlayerCombat")
    farm.get_node("ThreatDirector").enabled = false
    check(not paused and player.health == 5 and gm.saved_chickens == 0 and combat.ammunition == 8, "Reintentar restaura vida, estado, munición y ronda")
    data = gm.current_level.duplicate()
    data.goal_mode = LevelData.GoalMode.MONEY
    data.money_goal = 30
    await new_round(data)
    gm._on_deposited(1,30)
    check(gm.won_round, "Victoria por valor monetario en modo MONEY")
    data = gm.current_level.duplicate()
    data.goal_mode = LevelData.GoalMode.EITHER
    data.money_goal = 20
    data.bird_quota = 10
    await new_round(data)
    gm._on_deposited(1,20)
    check(gm.won_round, "Modo EITHER permite ganar por cualquiera de los dos objetivos")
    data = load("res://resources/levels/farm.tres").duplicate()
    await new_round(data)
    gm.remaining_seconds = 0.0
    gm.check_outcome()
    check(not gm.won_round and "tiempo" in gm.result_reason, "Tiempo agotado causa derrota")
    await new_round(data)
    # Aves del saco todavía cuentan como potencial recuperable, aunque no estén en mapa.
    var sack: ChickenSack = player.get_node("Sack")
    sack.try_add(load("res://resources/chickens/rare.tres"))
    gm.check_outcome()
    check(gm.state == gm.RoundState.PLAYING, "Tener aves en saco no provoca derrota por disponibilidad")
    gm._on_lost(10)
    gm._on_lost(10)
    gm._on_lost(10)
    gm._on_lost(10)
    check(gm.state == gm.RoundState.PLAYING, "La cuota sigue posible con ocho aves recuperables")
    gm._on_lost(10)
    check(gm.state == gm.RoundState.FINISHED and not gm.won_round and "disponibles" in gm.result_reason, "Derrota cuando pérdidas hacen imposible la cuota")
    await new_round(data)
    check(player.take_damage(5), "Daño letal válido reduce vida a cero")
    check(gm.state == gm.RoundState.FINISHED and not gm.won_round and "incapacitado" in gm.result_reason, "Vida cero provoca derrota por incapacitación")
    # Dinero y modo combinado: potencial monetario incluye los valores restantes.
    data = load("res://resources/levels/farm.tres").duplicate()
    data.goal_mode = LevelData.GoalMode.MONEY
    data.money_goal = 220
    await new_round(data)
    gm._on_lost(10)
    check(gm.state == gm.RoundState.PLAYING, "Objetivo monetario aún posible con valor restante exacto")
    gm._on_lost(10)
    check(gm.state == gm.RoundState.FINISHED and not gm.won_round, "Pérdidas de valor provocan derrota en modo MONEY")
    data = load("res://resources/levels/farm.tres").duplicate()
    data.goal_mode = LevelData.GoalMode.EITHER
    data.bird_quota = 11
    data.money_goal = 200
    await new_round(data)
    gm._on_lost(10)
    gm._on_lost(10)
    check(gm.state == gm.RoundState.PLAYING, "EITHER continúa mientras quede una vía de victoria posible")
    gm._on_lost(20)
    check(gm.state == gm.RoundState.FINISHED and not gm.won_round, "EITHER pierde solo cuando ambos objetivos son imposibles")
    await new_round()
    gm.remaining_seconds = 0.0
    gm._on_deposited(12,1000)
    check(not gm.won_round and gm.money == 0 and gm.saved_chickens == 0, "Depósito fuera de tiempo no cobra ni gana")
    # Nunca cobrar después de la derrota.
    gm._on_deposited(12,1000)
    check(gm.saved_chickens == 0 and gm.money == 0, "Marcador no acepta depósitos tras finalizar")
    paused = false
    farm.queue_free()
    await frames(4)
    gm.state = gm.RoundState.MENU
    print("PHASE5_RESULT: %d fallos" % failures)
    quit(0 if failures == 0 else 1)
