extends SceneTree
## Integración de IA, captura, inventario y depósito con escenas reales.
var failures: int = 0
var farm: Node
var player: FarmerPlayer
var sack: ChickenSack
var capture: Node
var reports: int = 0
const BIRD: PackedScene = preload("res://scenes/entities/chicken.tscn")

func _initialize() -> void:
    call_deferred("_run")

func frames(count: int) -> void:
    for i in range(count):
        await physics_frame

func check(condition: bool, message: String) -> void:
    if condition:
        print("PASS: " + message)
    else:
        failures += 1
        push_error("FAIL: " + message)

func spawn_bird(kind: String, point: Vector2, frozen: bool = true) -> FarmChicken:
    var bird: FarmChicken = BIRD.instantiate()
    bird.data = load("res://resources/chickens/" + kind + ".tres")
    bird.position = point
    farm.get_node("Depth").add_child(bird)
    bird.set_physics_process(not frozen)
    return bird

func _run() -> void:
    farm = load("res://scenes/levels/farm.tscn").instantiate()
    root.add_child(farm)
    current_scene = farm
    farm.get_node("ThreatDirector").enabled = false
    await frames(8)
    player = farm.get_node("Depth/Player")
    sack = player.get_node("Sack")
    capture = player.get_node("CaptureController")
    var gm: Node = root.get_node("GameManager")
    var birds: Array[Node] = get_nodes_in_group("chickens")
    check(birds.size() == 12, "Spawner usa las 12 aves de LevelData")
    var variants: Dictionary = {}
    var clear_spawn: bool = true
    for bird: FarmChicken in birds:
        variants[bird.data.id] = int(variants.get(bird.data.id, 0)) + 1
        var query := PhysicsShapeQueryParameters2D.new()
        query.shape = bird.get_node("Feet").shape
        query.transform = bird.get_node("Feet").global_transform
        query.collision_mask = 280
        if not player.get_world_2d().direct_space_state.intersect_shape(query).is_empty():
            clear_spawn = false
    check(clear_spawn, "Todos los puntos de aparición están libres de mundo y agua")
    check(variants.get(&"standard") == 6 and variants.get(&"wild") == 3 and variants.get(&"guardian") == 2 and variants.get(&"rare") == 1, "Distribución de cuatro variantes correcta")
    for bird in birds:
        bird.queue_free()
    await frames(3)
    var calm: FarmChicken = spawn_bird("standard", Vector2(820, 390), false)
    player.position = Vector2(608, 432)
    await frames(8)
    check(calm.state == FarmChicken.State.CALM, "Pollo lejano permanece en calma")
    player.position = calm.position + Vector2(-45, 0)
    await frames(8)
    check(calm.state == FarmChicken.State.ALERT, "Área detecta al jugador y activa alerta")
    check(calm.velocity.x > 0.0, "Pollo huye en dirección opuesta al jugador")
    player.position = Vector2(608, 432)
    await frames(80)
    check(calm.state == FarmChicken.State.CALM, "Sin amenaza regresa a calma tras memoria")
    calm.queue_free()
    await frames(3)
    var wild: Resource = load("res://resources/chickens/wild.tres")
    var normal: Resource = load("res://resources/chickens/standard.tres")
    var rare: Resource = load("res://resources/chickens/rare.tres")
    check(wild.flee_speed > normal.flee_speed, "Ágil tiene velocidad superior configurable")
    check(rare.reward > normal.reward, "Rara tiene mayor recompensa")
    var guard: FarmChicken = spawn_bird("guardian", Vector2(790, 390), false)
    player.position = Vector2(750, 390)
    guard._charge_cooldown = 0.0
    await frames(35)
    check(player.state == FarmerPlayer.State.STUNNED, "Guardián alcanza y aturde al granjero")
    guard.queue_free()
    await frames(60)
    player.position = Vector2(608, 432)
    player.velocity = Vector2.ZERO
    await frames(4)
    var distant: FarmChicken = spawn_bird("standard", Vector2(700, 432))
    check(not capture.capture_nearest(), "No captura fuera de alcance")
    distant.queue_free()
    await frames(18)
    # Una pared de prueba fina entre dos posiciones a menos de 30 px.
    var wall := StaticBody2D.new()
    wall.collision_layer = 8
    var shape := CollisionShape2D.new()
    var rectangle := RectangleShape2D.new()
    rectangle.size = Vector2(4, 32)
    shape.shape = rectangle
    wall.position = Vector2(620, 432)
    wall.add_child(shape)
    farm.add_child(wall)
    var hidden: FarmChicken = spawn_bird("standard", Vector2(631, 432))
    await frames(4)
    check(not capture.capture_nearest(), "Pared bloquea captura dentro del alcance")
    wall.queue_free()
    hidden.queue_free()
    await frames(18)
    var expected_value: int = 0
    for kind in ["standard", "standard", "wild", "guardian", "rare", "standard"]:
        var bird: FarmChicken = spawn_bird(kind, player.position + Vector2(20, 0))
        expected_value += bird.data.reward
        check(capture.capture_nearest(), "Captura válida: " + kind)
        check(not bird.try_capture(sack), "La misma instancia no puede duplicarse")
        await frames(18)
    check(sack.count() == 6, "Saco contiene exactamente seis aves")
    check(gm.money == 0 and gm.saved_chickens == 0, "Capturar no entrega recompensa antes del corral")
    var extra: FarmChicken = spawn_bird("standard", player.position + Vector2(20, 0))
    check(not capture.capture_nearest(), "Séptima captura rechazada con saco lleno")
    check(not extra.is_claimed and sack.count() == 6, "Aves rechazadas siguen disponibles")
    farm.get_node("CoopArea").deposited.connect(func(_count: int, _value: int) -> void: reports += 1)
    player.position = Vector2(640, 329)
    player.velocity = Vector2.ZERO
    await frames(10)
    check(sack.count() == 0, "Entrar al corral vacía el saco")
    check(gm.saved_chickens == 6 and gm.money == expected_value, "Depósito suma aves y valores individuales exactos")
    check(reports == 1, "Señal de depósito emitida una sola vez")
    await frames(20)
    check(gm.saved_chickens == 6 and gm.money == expected_value and reports == 1, "Permanecer dentro no duplica la recompensa")
    # Capturar permaneciendo dentro también debe descargar sin exigir salir/entrar.
    extra.position = player.position + Vector2(20, 0)
    await frames(18)
    check(capture.capture_nearest(), "Puede capturar estando dentro del corral")
    await frames(6)
    check(sack.count() == 0 and gm.saved_chickens == 7 and reports == 2, "Capturar dentro se deposita automáticamente")
    check(farm.get_node("HUD/Bag").text == "Pollos en saco: 0 / 6", "HUD de saco coincide con inventario")
    check("7 / 8" in farm.get_node("HUD/Score").text, "HUD muestra progreso hacia cuota de LevelData")
    # Reset comprueba que la siguiente partida no herede el saldo.
    gm.reset_round()
    check(gm.saved_chickens == 0 and gm.money == 0, "Reiniciar ronda limpia marcador")
    print("PHASE3_RESULT: %d fallos" % failures)
    quit(0 if failures == 0 else 1)
