extends SceneTree
## Prueba de integración real: física, InputMap y controlador en el mapa entregado.
var player: FarmerPlayer
var failures: int = 0

func _initialize() -> void:
    call_deferred("_run")

func frames(count: int) -> void:
    for i in range(count):
        await physics_frame

func check(condition: bool, message: String) -> void:
    if condition:
        print("PASS: " + message)
    else:
        push_error("FAIL: " + message)
        failures += 1

func reset_at(point: Vector2) -> void:
    for action in ["move_left", "move_right", "move_up", "move_down", "run", "jump"]:
        Input.action_release(action)
    player.global_position = point
    player.velocity = Vector2.ZERO
    await frames(3)

func _run() -> void:
    var farm: Node = load("res://scenes/levels/farm.tscn").instantiate()
    root.add_child(farm)
    current_scene = farm
    farm.get_node("ThreatDirector").enabled = false
    await frames(5)
    player = farm.get_node("Depth/Player")
    check(player != null, "Nivel y Player cargan")
    check(InputMap.action_get_events("move_left")[1].physical_keycode == KEY_LEFT, "Flecha izquierda correcta")
    check(InputMap.action_get_events("move_right")[1].physical_keycode == KEY_RIGHT, "Flecha derecha correcta")
    await reset_at(Vector2(608, 432))
    Input.action_press("move_right")
    await frames(35)
    check(player.position.x > 645, "Caminar desplaza el cuerpo")
    check(player.state == FarmerPlayer.State.WALKING, "Estado Caminar")
    Input.action_press("move_down")
    await frames(15)
    check(player.velocity.length() <= player.walk_speed + 0.1, "Diagonal no supera velocidad de caminar")
    await reset_at(Vector2(608, 432))
    Input.action_press("move_right")
    Input.action_press("run")
    await frames(20)
    check(player.state == FarmerPlayer.State.RUNNING, "Estado Correr")
    check(player.stamina < 100.0, "Correr consume estamina")
    await frames(220)
    check(player.state != FarmerPlayer.State.RUNNING, "Agotar estamina impide correr")
    Input.action_release("move_right")
    Input.action_release("run")
    var before: float = player.stamina
    await frames(15)
    check(player.stamina <= before + 0.1, "Retraso antes de regenerar")
    await frames(220)
    check(is_equal_approx(player.stamina, player.max_stamina), "Reposo recupera estamina")
    await reset_at(Vector2(608, 432))
    player.stun(1.0)
    Input.action_press("move_right")
    await frames(20)
    check(player.state == FarmerPlayer.State.STUNNED, "Estado Aturdido")
    check(absf(player.position.x - 608.0) < 2.0, "Aturdido bloquea movimiento")
    Input.action_release("move_right")
    await frames(70)
    check(player.state == FarmerPlayer.State.IDLE, "Recuperación del aturdimiento")
    await reset_at(Vector2(832, 420))
    Input.action_press("move_down")
    await frames(80)
    check(player.position.y < 443.0, "Agua bloquea el paso")
    Input.action_press("jump")
    await frames(60)
    check(player.position.y < 443.0, "Salto no atraviesa agua")
    await reset_at(Vector2(928, 420))
    Input.action_press("move_down")
    await frames(180)
    check(player.position.y > 675.0, "Puente permite cruzar el estanque")
    await reset_at(Vector2(608, 490))
    Input.action_press("move_down")
    await frames(30)
    check(player.position.y < 510.0, "Raíz bloquea al caminar")
    Input.action_press("jump")
    await frames(40)
    check(player.position.y > 533.0, "Salto atraviesa raíz")
    check(not player.is_airborne, "Salto termina y restaura colisión")
    await reset_at(Vector2(608, 490))
    Input.action_press("move_down")
    Input.action_press("jump")
    await frames(18)
    Input.action_release("move_down")
    await frames(40)
    check(not player.is_airborne, "Detenerse encima de raíz no causa flotación")
    check(player.get_collision_mask_value(9), "Máscara de obstáculos bajos restaurada")
    await reset_at(Vector2(28, 400))
    Input.action_press("move_left")
    Input.action_press("jump")
    await frames(70)
    check(player.position.x > 22.0, "Borde no se cruza ni saltando")
    var camera: Camera2D = player.get_node("Camera2D")
    check(camera.limit_right == 1280 and camera.limit_bottom == 768, "Cámara usa límites del mapa")
    var center: Vector2 = camera.get_screen_center_position()
    check(center.x >= 320.0 and center.x <= 960.0, "Cámara no muestra fuera de límites horizontales")
    check(center.y >= 180.0 and center.y <= 588.0, "Cámara no muestra fuera de límites verticales")
    Input.action_release("move_left")
    Input.action_release("jump")
    print("PHASE2_RESULT: " + str(failures) + " fallos")
    quit(0 if failures == 0 else 1)
