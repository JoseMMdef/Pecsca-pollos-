extends SceneTree
## Pruebas de integración reales para fugas, reparación, red y trampas.
var failures: int = 0
var farm: Node
var player: FarmerPlayer
var tools: Node
var sack: ChickenSack
var gm: Node
const BIRD: PackedScene = preload("res://scenes/entities/chicken.tscn")
const TRAP: PackedScene = preload("res://scenes/entities/trap.tscn")

func _initialize() -> void:
    call_deferred("_run")

func frames(count: int) -> void:
    for i in range(count):
        await physics_frame

func check(condition: bool, message: String) -> void:
    if condition:
        print("PASS: " + message)
    else:
        failures += 1
        push_error("FAIL: " + message)

func spawn_bird(point: Vector2, frozen: bool = true) -> FarmChicken:
    var bird: FarmChicken = BIRD.instantiate()
    bird.data = load("res://resources/chickens/wild.tres")
    bird.position = point
    bird.escaped.connect(func(data: ChickenData) -> void: root.get_node("EventBus").chicken_lost.emit(data.reward))
    farm.get_node("Depth").add_child(bird)
    bird.set_physics_process(not frozen)
    return bird

func wall_at(point: Vector2) -> StaticBody2D:
    var wall := StaticBody2D.new()
    var shape := CollisionShape2D.new()
    var rectangle := RectangleShape2D.new()
    rectangle.size = Vector2(4, 60)
    shape.shape = rectangle
    wall.collision_layer = 8
    wall.position = point
    wall.add_child(shape)
    farm.add_child(wall)
    return wall

func _run() -> void:
    farm = load("res://scenes/levels/farm.tscn").instantiate()
    root.add_child(farm)
    current_scene = farm
    farm.get_node("ThreatDirector").enabled = false
    await frames(8)
    player = farm.get_node("Depth/Player")
    tools = player.get_node("FieldTools")
    sack = player.get_node("Sack")
    gm = root.get_node("GameManager")
    for bird in get_nodes_in_group("chickens"):
        bird.queue_free()
    await frames(4)
    player.position = Vector2(608, 432)
    player.velocity = Vector2.ZERO
    player.facing = Vector2.RIGHT
    var front: FarmChicken = spawn_bird(Vector2(668, 432), false)
    var behind: FarmChicken = spawn_bird(Vector2(558, 432))
    var far: FarmChicken = spawn_bird(Vector2(708, 432))
    check(tools.use_net() == 1, "Red alcanza solo el ave al frente dentro de rango")
    check(tools.use_net() == 0, "Enfriamiento impide repetir red inmediatamente")
    check(behind._net_time == 0.0 and far._net_time == 0.0, "Red no afecta espalda ni aves lejanas")
    var start: Vector2 = front.position
    await frames(70)
    check(front.position.distance_to(start) < 1.0, "Red inmoviliza temporalmente un pollo ágil")
    check(sack.count() == 0, "Red no embolsa automáticamente")
    player.position = front.position - Vector2(20, 0)
    check(player.get_node("CaptureController").capture_nearest(), "E captura un ave retenida por red")
    await frames(3)
    check(sack.count() == 1, "Ave capturada por red cuenta una vez en saco")
    sack.take_all()
    behind.queue_free()
    far.queue_free()
    await frames(10)
    player.position = Vector2(608, 432)
    player.facing = Vector2.RIGHT
    var hidden: FarmChicken = spawn_bird(Vector2(668, 432))
    var wall: StaticBody2D = wall_at(Vector2(640, 432))
    await frames(4)
    check(tools.use_net() == 0 and hidden._net_time == 0.0, "Red respeta paredes")
    wall.queue_free()
    hidden.queue_free()
    await frames(55)
    var held: FarmChicken = spawn_bird(Vector2(668, 432), false)
    tools.use_net()
    await frames(190)
    check(held._net_time <= 0.0 and held.velocity.length() > 0.0, "La inmovilización por red expira")
    held.queue_free()
    await frames(4)
    # Colocación: conservar suministros cuando falla.
    player.position = Vector2(832, 420)
    player.facing = Vector2.DOWN
    check(tools.place_trap() == null and tools.baits == 3, "Colocación sobre agua rechazada sin gastar carnada")
    await frames(20)
    player.position = Vector2(608, 432)
    player.facing = Vector2.RIGHT
    var trap: BaitTrap = tools.place_trap()
    check(trap != null and tools.baits == 2, "Colocar trampa válida consume una carnada")
    await frames(20)
    check(not tools.can_place_at(trap.position), "No superponer trampas")
    check(not tools.can_place_at(Vector2(640, 329)), "No colocar trampas en el corral")
    check(not tools.can_place_at(Vector2(20, 20)), "No colocar trampas fuera del área válida")
    trap.queue_free()
    await frames(4)
    # Atracción en calma: jugador lejos de su radio de alarma.
    player.position = Vector2(608, 432)
    trap = TRAP.instantiate()
    trap.position = Vector2(820, 390)
    farm.get_node("Depth").add_child(trap)
    var lure_bird: FarmChicken = spawn_bird(Vector2(780, 390), false)
    await frames(20)
    check(lure_bird.position.x > 780.0, "Carnada atrae aves en calma")
    await frames(150)
    check(trap.state == BaitTrap.State.OCCUPIED and lure_bird.is_trapped(), "Trampa retiene automáticamente un ave")
    var other: FarmChicken = spawn_bird(trap.position)
    await frames(8)
    check(not other.is_trapped(), "Trampa ocupada no retiene una segunda ave")
    var trapped_position: Vector2 = lure_bird.position
    player.position = trapped_position - Vector2(22, 0)
    await frames(20)
    check(lure_bird.position.distance_to(trapped_position) < 1.0, "Ave retenida no huye al acercarse el jugador")
    other.queue_free()
    await frames(3)
    check(player.get_node("CaptureController").capture_nearest(), "E embolsa el ave de una trampa")
    await frames(4)
    check(sack.count() == 1 and not is_instance_valid(trap), "Trampa usada se consume tras la captura")
    sack.take_all()
    # Al retirar una trampa, su ave vuelve a quedar libre.
    trap = TRAP.instantiate()
    trap.position = Vector2(820, 390)
    farm.get_node("Depth").add_child(trap)
    var released: FarmChicken = spawn_bird(trap.position)
    await frames(6)
    check(released.is_trapped(), "Trampa preparada retiene al entrar")
    trap.queue_free()
    await frames(4)
    check(not released.is_trapped(), "Destruir trampa libera al ave restante")
    released.queue_free()
    # Límite de tres carnadas totales, no tres simultáneas.
    player.position = Vector2(608, 432)
    player.facing = Vector2.LEFT
    await frames(20)
    var second: BaitTrap = tools.place_trap()
    await frames(20)
    player.facing = Vector2.DOWN
    var third: BaitTrap = tools.place_trap()
    await frames(20)
    player.facing = Vector2.UP
    check(second != null and third != null and tools.baits == 0, "Tres carnadas disponibles por partida")
    check(tools.place_trap() == null, "Sin carnadas no se crean nuevas trampas")
    second.queue_free()
    third.queue_free()
    await frames(4)
    # Fugas: cruce de línea en alerta; calma no se pierde.
    var gap: FenceGap = farm.get_node("Depth/FenceGapWest")
    player.position = Vector2(500, 700)
    var calm: FarmChicken = spawn_bird(Vector2(320, 760))
    await frames(8)
    check(not calm.is_claimed and gm.lost_chickens == 0, "Un ave tranquila en el hueco no se pierde")
    calm.state = FarmChicken.State.ALERT
    await frames(6)
    check(gm.lost_chickens == 1 and not is_instance_valid(calm), "Ave asustada cruza el hueco y se pierde")
    await frames(10)
    check(gm.lost_chickens == 1 and gm.money == 0, "Pérdida se cuenta una sola vez sin recompensa")
    var race: FarmChicken = spawn_bird(Vector2(320, 760))
    race.state = FarmChicken.State.ALERT
    check(race.try_capture(sack), "Captura puede reclamar ave antes de la fuga")
    check(not race.try_escape(), "Un ave capturada no puede perderse después")
    await frames(4)
    check(gm.lost_chickens == 1 and sack.count() == 1, "Sin duplicación entre captura y fuga")
    sack.take_all()
    # Barrera especial: el jugador no sale aunque el hueco esté abierto.
    player.position = Vector2(320, 720)
    player.velocity = Vector2.ZERO
    Input.action_press("move_down")
    await frames(60)
    Input.action_release("move_down")
    player.velocity = Vector2.ZERO
    check(player.position.y < 745.0, "Hueco no permite al jugador abandonar el mapa")
    # Reparación sostenida y cancelación.
    player.position = Vector2(320, 720)
    Input.action_press("repair")
    await frames(30)
    check(not gap.repaired, "Reparar requiere mantener C durante el tiempo configurado")
    Input.action_release("repair")
    await frames(5)
    check(is_zero_approx(tools._repair_elapsed), "Soltar C cancela progreso de reparación")
    player.position = Vector2(500, 700)
    Input.action_press("repair")
    await frames(90)
    check(not gap.repaired, "No se puede reparar fuera de alcance")
    Input.action_release("repair")
    await frames(4)
    player.position = Vector2(320, 720)
    Input.action_press("repair")
    await frames(90)
    Input.action_release("repair")
    await frames(3)
    check(gap.repaired, "Mantener C cerca repara la cerca")
    check(gap.get_node("RepairedFence").collision_layer == 8, "Reparación activa la colisión del mundo")
    check(not gap.complete_repair(), "Reparación no se aplica dos veces")
    var safe: FarmChicken = spawn_bird(Vector2(320, 760))
    safe.state = FarmChicken.State.ALERT
    await frames(10)
    check(not safe.is_claimed and gm.lost_chickens == 1, "Hueco reparado ya no consume aves")
    safe.queue_free()
    await frames(3)
    var blocked: FarmChicken = spawn_bird(Vector2(320, 730), false)
    blocked._net_time = 0.0
    player.position = Vector2(320, 690)
    await frames(60)
    check(blocked.position.y < 746.0, "Cerca reparada bloquea físicamente a las aves")
    check("Perdidas: 1" in farm.get_node("HUD/Score").text, "HUD muestra pérdidas registradas")
    check("Carnadas: 0" in farm.get_node("HUD/Tools").text, "HUD refleja inventario de carnada")
    farm.queue_free()
    await frames(4)
    print("PHASE4_RESULT: %d fallos" % failures)
    quit(0 if failures == 0 else 1)
