extends Node
## Contrato del progreso. Persistencia y migración de archivos: fase 7.
var unlocked_level: int = 1
