extends Node
## Autoridad de ronda: configuración compartida, contadores y resultado inmutable.
signal score_changed(saved: int, lost: int, money_total: int)
signal clock_changed(seconds: float)
signal health_changed(current: int)
signal finished(won: bool, reason: String)
enum RoundState { MENU, PLAYING, PAUSED, FINISHED }
var state: RoundState = RoundState.MENU
var saved_chickens: int = 0
var lost_chickens: int = 0
var money: int = 0
var current_level: LevelData
var remaining_seconds: float = 180.0
var health: int = 5
var total_birds: int = 0
var total_value: int = 0
var lost_value: int = 0
var won_round: bool = false
var result_reason: String = ""

func _ready() -> void:
    EventBus.chicken_deposited.connect(_on_deposited)
    EventBus.chicken_lost.connect(_on_lost)
    EventBus.player_health_changed.connect(_on_health)

func reset_round() -> void:
    saved_chickens = 0
    lost_chickens = 0
    money = 0
    lost_value = 0
    health = 5
    total_birds = 0
    total_value = 0
    won_round = false
    result_reason = ""
    if current_level != null:
        remaining_seconds = current_level.round_seconds
        for index in range(current_level.chicken_counts.size()):
            var count: int = current_level.chicken_counts[index]
            total_birds += count
            total_value += count * current_level.chicken_types[index].reward
    state = RoundState.PLAYING
    score_changed.emit(saved_chickens, lost_chickens, money)
    clock_changed.emit(remaining_seconds)
    health_changed.emit(health)

func _process(delta: float) -> void:
    if state != RoundState.PLAYING or current_level == null:
        return
    remaining_seconds = maxf(0.0, remaining_seconds - delta)
    clock_changed.emit(remaining_seconds)
    check_outcome()

func _on_deposited(count: int, value: int) -> void:
    if state != RoundState.PLAYING:
        return
    if remaining_seconds <= 0.0:
        check_outcome()
        return
    saved_chickens += count
    money += value
    score_changed.emit(saved_chickens, lost_chickens, money)
    check_outcome()

func _on_lost(value: int) -> void:
    if state != RoundState.PLAYING:
        return
    lost_chickens += 1
    lost_value += value
    score_changed.emit(saved_chickens, lost_chickens, money)
    check_outcome()

func _on_health(current: int) -> void:
    health = current
    health_changed.emit(health)
    if state == RoundState.PLAYING:
        check_outcome()

func check_outcome() -> void:
    if state != RoundState.PLAYING or current_level == null:
        return
    if health <= 0:
        finish(false, "El granjero quedó incapacitado.")
        return
    if remaining_seconds <= 0.0:
        finish(false, "Se acabó el tiempo de la ronda.")
        return
    var bird_goal: bool = saved_chickens >= current_level.bird_quota
    var money_goal: bool = money >= current_level.money_goal
    var birds_possible: bool = total_birds - lost_chickens >= current_level.bird_quota
    var money_possible: bool = total_value - lost_value >= current_level.money_goal
    var goal: bool
    var possible: bool
    match current_level.goal_mode:
        LevelData.GoalMode.BIRDS:
            goal = bird_goal
            possible = birds_possible
        LevelData.GoalMode.MONEY:
            goal = money_goal
            possible = money_possible
        _:
            goal = bird_goal or money_goal
            possible = birds_possible or money_possible
    if goal:
        finish(true, "¡Objetivo alcanzado a tiempo!")
    elif not possible:
        finish(false, "Las aves disponibles ya no alcanzan para el objetivo.")

func finish(won: bool, reason: String) -> void:
    ## Idempotente: ninguna señal o evento tardío puede cambiar un resultado.
    if state != RoundState.PLAYING:
        return
    state = RoundState.FINISHED
    won_round = won
    result_reason = reason
    finished.emit(won, reason)
    EventBus.round_finished.emit(won)
