extends Node
## Valida la ruta antes de cambiar escena. El fade se implementa en fase 6.
func change_scene(path: String) -> Error:
    if not ResourceLoader.exists(path):
        push_error("Escena inexistente: " + path)
        return ERR_FILE_NOT_FOUND
    return get_tree().change_scene_to_file(path)
