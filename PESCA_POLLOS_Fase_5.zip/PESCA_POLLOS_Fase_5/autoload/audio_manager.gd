extends Node
## Reserva del servicio de audio. Los buses y pistas se incorporan en fase 7.
var music_enabled: bool = true
var effects_enabled: bool = true
