extends Node
## Contratos de comunicación. Las mecánicas emitirán estas señales en fases siguientes.
signal chicken_deposited(count: int, value: int)
signal chicken_lost(value: int)
signal player_health_changed(health: int)
signal round_finished(won: bool)
