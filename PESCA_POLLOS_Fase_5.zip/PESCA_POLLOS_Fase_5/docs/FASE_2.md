# PESCA POLLOS — Fase 2
TecNM Mérida · Tópicos Avanzados de Programación

## Qué se entrega
Proyecto completo acumulativo. Movimiento de ocho direcciones, orientación visual de cuatro direcciones, Idle/Caminar/Correr/Aturdido, estamina, salto, cámara y La Granja (40×24 tiles, 1280×768 px). Captura, saco y depósito se implementan en fase 3. Vida y daño, en fase 5. No se adelantaron pantallas o mecánicas de esas fases.

El granjero es un dibujo provisional de píxeles construido con draw_rect en FarmerVisual: la lámina adjunta no incluía una hoja de granjero animado. Tiene idle, alternancia de pasos en cuatro orientaciones y señal visual de aturdimiento. No se presenta como arte definitivo ni como un AnimatedSprite2D con fotogramas originales. Se reemplaza cambiando el nodo visual; movimiento y colisión no dependen del dibujo. El puente usa tablones dibujados por código sobre su TileMapLayer, porque en la referencia solo aparecía dentro del ejemplo de mapa. Los terrenos, árboles, cercas, casa y gallinero usan el atlas adaptado de fase 1.

## Importación (sin copiar archivos sueltos)
1. Extraer este ZIP en una carpeta nueva, distinta de la fase 1.
2. Godot → Proyecto → Salir a la lista de proyectos (si ya hay uno abierto).
3. Administrador de proyectos → Importar → elegir project.godot dentro de PESCA_POLLOS_Fase_2.
4. Importar y editar; esperar que termine la importación.
5. F5 abre scenes/levels/farm.tscn.

No hay conexiones de señales ni configuración obligatoria del editor por hacer: todo está incluido. F6 sobre atlas_lab.tscn conserva el laboratorio de la fase 1.

## Controles
| Acción | Teclado | Mando |
|---|---|---|
| Mover | WASD / flechas | Stick izquierdo / cruceta |
| Correr | Mantener Shift | Mantener pulsado stick izquierdo |
| Saltar | Espacio | B / botón 1 |
| Probar aturdimiento | F8 (solo debug) | — |

Los controles táctiles se incorporan en fase 6. Las acciones de captura, red y disparo existen en InputMap pero aún no ejecutan esas mecánicas.

## Jerarquía exacta de Player.tscn
```
Player (CharacterBody2D, player.gd, grupo player)
├── Shadow (Polygon2D)
├── VisualPivot (Node2D)
│   └── FarmerVisual (Node2D, farmer_visual.gd)
├── GroundShape (CollisionShape2D, círculo radio 6)
└── Camera2D
```
Movimiento floating, capa Player (1), máscara World + Water + LowObstacle = 8 + 16 + 256 = 280. Camera2D tiene límites 0,0–1280,768, sin suavizado para evitar subpíxeles. Su posición local es (0,-40) para reservar algo más de pantalla hacia delante del granjero y espacio para el HUD.

## Jerarquía del nivel
La lista completa, con cada cerca, árbol y colisión individual, está en JERARQUIA_NIVEL.txt, extraída de la escena final.
```
Farm (Node2D)
├── Terrain (Node2D, farm_ground.gd, @tool)
│   ├── Ground (TileMapLayer)
│   ├── Paths (TileMapLayer)
│   ├── Water (TileMapLayer)
│   ├── Bridge (TileMapLayer)
│   └── BridgeDeck (Node2D, bridge_visual.gd)
├── Depth (Node2D, Y-Sort)
│   ├── Farmhouse, CoopBuilding (Sprite2D)
│   ├── Tree00…Tree10 (Sprite2D)
│   ├── Bush00…Bush04 (Sprite2D)
│   ├── Rock00…Rock02 (Sprite2D)
│   ├── FenceTop…, FenceBottom…, FenceLeft…, FenceRight… (Sprite2D)
│   ├── CoopFence… (Sprite2D)
│   ├── Root (Node2D, root_visual.gd)
│   └── Player (instancia de player.tscn)
├── WorldCollision (Node2D)
│   └── cuerpos StaticBody2D nombrados + Shape (CollisionShape2D)
├── SpawnPoints (Node2D)
│   └── PlayerSpawn (Marker2D)
└── HUD (CanvasLayer, phase2_hud.gd)
    ├── Panel (Panel)
    │   ├── Title (Label)
    │   ├── State (Label)
    │   ├── StaminaText (Label)
    │   ├── Stamina (ProgressBar)
    │   └── Jump (Label)
    └── Controls (Label)
```

## Decisiones de diseño para explicar en clase
- **Un controlador y un visual separado:** Player decide física y estado; FarmerVisual solo representa orientación, pasos y aturdimiento. Las señales actualizan el HUD sin que Player conozca su jerarquía.
- **FSM pequeña:** enum State con transiciones en _physics_process y _set_state. Cuatro estados no necesitan cuatro scripts vacíos. El salto es una condición ortogonal: se puede caminar o correr mientras se salta.
- **Velocidad independiente de FPS:** velocity está en px/s; move_and_slide aplica el paso físico. Solo la aceleración, estamina y temporizadores se multiplican por delta.
- **Diagonal correcta:** Input.get_vector limita la longitud a uno, conservando la intensidad analógica del stick.
- **Estamina:** 100 puntos, consumo 28/s; espera 0.85 s antes de regenerar, 32/s en reposo y 12/s caminando. Al agotarse, se exige recuperar 25% para correr otra vez. Shift sin movimiento no consume.
- **Salto top-down:** curva seno de 21 px y duración 0.55 s en VisualPivot. El cuerpo físico conserva coordenadas de suelo y Y-Sort sigue usando los pies. Solo se ignora LowObstacle; agua y paredes siguen bloqueando. Si al aterrizar hay una raíz, vuelve al último punto libre de la trayectoria. is_airborne permitirá comprobar esquiva en fase 5; no hay depredadores todavía.
- **Profundidad:** Player, árboles y edificios son hijos directos de Depth. Los Sprite2D tienen el pivote en el borde inferior. No se agrupan bajo padres intermedios que rompan la comparación de Y.
- **Colisión de pies:** árboles/edificios bloquean su base, no toda la copa o techo, para poder pasar por detrás.
- **Agua y puente:** el estanque ocupa (768,448)–(1120,672). El paso está entre x=896 y x=960. WaterWest y WaterEast dejan esa franja libre. Dos barandas evitan salirse lateralmente del puente.
- **Terreno reproducible:** farm_ground.gd pinta cuatro TileMapLayer con semilla fija tanto en editor como al ejecutar. Su script repinta al cargar: modificar el layout requiere editar sus bucles. Los props y cuerpos físicos sí son nodos editables de la escena. No hay autotile ni terrenos automáticos configurados.
- **Escena estática:** casa, árboles, cercas y cuerpos están guardados en farm.tscn; no aparecen únicamente al ejecutar. Cuerpos rectangulares con tamaños explícitos, sin escalas físicas no uniformes.

## Colisiones nuevas
Se conservan las capas de fase 1. Capa 9: LowObstacle, bit 256. Root usa esa capa y un rectángulo de 48×10 px. Player desactiva y restaura únicamente el bit 9 al saltar. Las capas 6 BridgeReserved y 7 Zones no generan barreras en esta fase. El espacio del futuro depósito está libre; no es todavía CoopArea.

## Prueba manual (5 minutos)
1. Al pulsar F5, el granjero aparece en el camino central. Caminar en las ocho direcciones: revisar que no se acelera en diagonal y que cambia orientación.
2. Mantener Shift y moverse: la barra baja. Al agotarla, deja de correr. Soltar y detenerse: tras la pausa la barra vuelve a subir.
3. Desde el inicio ir al sur: hay una raíz horizontal en (608,520). Sin saltar bloquea; Espacio + avanzar permite pasarla. Detenerse sobre ella durante un salto debe devolver al último lugar libre y terminar el salto.
4. Ir al estanque al sureste. Intentar entrar en el agua por los lados, incluso saltando: queda bloqueado. Cruzar por el centro del puente en ambas direcciones.
5. Rodear un árbol: detrás de la copa el jugador queda oculto; delante de los pies se dibuja delante. Casa y gallinero no permiten atravesar su base.
6. Llegar a los cuatro bordes: cercas y límites impiden salir; cámara no muestra vacío fuera del mapa.
7. F8 activa Aturdido durante un segundo. Durante ese lapso no se puede caminar, correr ni iniciar un salto. Después vuelve al estado correspondiente a la entrada.
8. Depurador: no deben aparecer errores. Activar Depurar → Formas de colisión visibles permite ver el cuerpo de pies y el canal libre del puente.

## Ajustes del editor que puedes hacer
- Player.tscn → nodo Player: walk_speed, run_speed, consumo/regeneración y salto son propiedades exportadas en el Inspector.
- Camera2D → Limit: cambiar los cuatro límites al ampliar el mapa. Mantener coherencia con geometría, bordes y terreno.
- Farm.tscn → Depth: mover cada prop y su cuerpo correspondiente en WorldCollision juntos. No modificar solo el dibujo.
- Los parámetros de fase 2 son demostrativos y ajustables. LevelData para cuotas/spawners se conectará al gameplay en fases siguientes.

## Verificación automatizada incluida
Importación real y prueba de integración ejecutadas con Godot 4.4.1 estable para Linux en modo headless. No se ha ejecutado Godot 4.7.2 ni Android. El registro está en pruebas_fase2.txt. La revisión visual final en tu editor sigue siendo necesaria.

Para repetir con tu ejecutable:
```
Godot --headless --path RUTA_DEL_PROYECTO --editor --import --quit
Godot --headless --path RUTA_DEL_PROYECTO --script res://tests/phase2_test.gd --fixed-fps 60
```
En Windows sustituye Godot por la ruta de tu ejecutable de consola y entrecomilla la ruta si contiene espacios. La prueba crea el nivel real, simula entradas y comprueba movimiento, estamina, salto y colisiones. No usa capturas de pantalla.

## Código completo
- scripts/entities/player.gd: movimiento, FSM, estamina, salto y consulta de aterrizaje.
- scripts/entities/farmer_visual.gd: visual provisional.
- scripts/levels/farm_ground.gd: TileMapLayer del terreno.
- scripts/levels/bridge_visual.gd y root_visual.gd: puente y raíz.
- scripts/ui/phase2_hud.gd: señales y HUD de prueba.
- tests/phase2_test.gd: comprobaciones reproducibles.
- scenes/entities/player.tscn y scenes/levels/farm.tscn: escenas completas.

## Documentación técnica consultada
https://docs.godotengine.org/en/stable/classes/class_characterbody2d.html
https://docs.godotengine.org/en/stable/classes/class_tilemaplayer.html
https://docs.godotengine.org/en/stable/classes/class_canvasitem.html
https://docs.godotengine.org/en/stable/classes/class_physicsshapequeryparameters2d.html

## Antes de fase 3
Confirmar movimiento, aspecto y tamaño del jugador, puente y cámara. Después se integrarán gallinas, captura, saco y CoopArea con HUD de recolección.
