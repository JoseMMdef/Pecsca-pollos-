# PESCA POLLOS — Fase 5
TecNM Mérida · Tópicos Avanzados de Programación

## Alcance
Proyecto acumulativo: zorros, águilas, escopeta, espantapájaros, cinco corazones, reloj, objetivos y fin de ronda. Conserva lo funcional de las fases anteriores y el arte provisional. Los nuevos depredadores y estructuras también usan dibujos nativos provisionales: el acabado visual y las animaciones definitivas se afinarán después, como se acordó.

Se incluye un resumen funcional con Reintentar para poder verificar todos los resultados. Menú principal, pausa manual, ajustes, controles táctiles, Nivel 2 y navegación al siguiente nivel siguen en fase 6. Audio y persistencia siguen en fase 7.

## Abrir
1. Extraer PESCA_POLLOS_Fase_5.zip en una carpeta nueva.
2. Godot → Administrador de proyectos → Importar → project.godot.
3. Importar y editar; esperar la importación y pulsar F5.

Todos los nodos, InputMap y conexiones necesarias están incluidos. No hay pasos manuales obligatorios del editor. No copiar solo algunos scripts sobre otra fase: esta entrega contiene el proyecto completo.

## Controles
| Acción | Teclado | Mando actual |
|---|---|---|
| Movimiento | WASD / flechas | Stick izquierdo / cruceta |
| Correr | Shift | Pulsar stick izquierdo |
| Saltar / esquivar | Espacio | B / botón 1 |
| Capturar | E | A / botón 0 |
| Red | Q | X / botón 2 |
| Carnada | T | Y / botón 3 |
| Reparar hueco | Mantener C | Pendiente |
| Escopeta | F | Pulsar stick derecho / botón 10 |
| Colocar espantapájaros | R | Pendiente |

Disparar y usar la red apuntan hacia la última orientación cardinal del granjero. Caminar primero en esa dirección permite apuntar. No se dispara ni se coloca espantapájaros durante salto o aturdimiento. Los controles táctiles llegan en fase 6.

## Parámetros de La Granja
| Parámetro | Valor inicial |
|---|---:|
| Vida | 5 corazones |
| Tiempo | 180 s |
| Cuota | 8 aves depositadas |
| Munición | 8 cargas |
| Espantapájaros | 2 |
| Carnadas | 3 |
| Primera manada | 12 s |
| Intervalo de zorros | 30 s |
| Tamaño de manada | 2 |
| Primera parvada | 25 s |
| Intervalo de águilas | 60 s |
| Tamaño de parvada | 2 |
| Máximo simultáneo | 4 zorros y 4 águilas |

Tiempo, cuota, munición, oleadas, límites y suministro de espantapájaros están en resources/levels/farm.tres mediante LevelData. Se mantienen las 12 aves de la fase 3. La cuota requiere depósito: llevar aves en el saco no otorga victoria todavía.

## Fox
Fox.tscn es CharacterBody2D. Su cuerpo usa Predator=4 y máscara World/Water/LowObstacle=280. Respeta cercas, agua y raíces; usa el puente como cualquier cuerpo terrestre. No bloquea físicamente al jugador: el contacto cercano le causa daño.

Cada 0.5 s elige un ave considerando concentraciones a 140 px y distancia al zorro. Si no hay aves, patrulla las lindes. Usa sondeos locales y move_and_slide; no es navegación global de laberintos. Puede atascarse temporalmente en diseños complejos; en Nivel 2 habrá que revisar sus recorridos y evolucionar la navegación si es necesario.

Al acercarse a 17 px con línea de visión libre, roba una única ave y abandona la escena. La pérdida no genera dinero. Puede robar aves inmovilizadas por red o carnada; una trampa no es protección contra depredadores. Si el ave retenida se pierde, la trampa también se consume. No puede robar a través de una cerca o pared.

Un perdigón válido lo elimina/espanta sin representar violencia gráfica. El estado de retirada impide que varios perdigones registren varias eliminaciones sobre la misma instancia.

## Eagle
Eagle.tscn usa CharacterBody2D con Predator=4 y máscara 0. Su posición física representa la proyección sobre el suelo; Art se dibuja elevado. Vuela sobre obstáculos sin colisión terrestre.

Estados:
1. CRUISE: busca un ave fuera de zonas protegidas y vuela hacia ella.
2. WARNING: fija una sombra y un ! en el lugar de aviso durante 1.4 s.
3. DIVE: desciende durante 0.55 s y persigue rápidamente al objetivo; vulnerable a disparos en esta fase.
4. RETREAT: se eleva y se retira.

El aviso inicial queda fijado; durante la picada la sombra se mueve con el descenso que sigue al ave. Las aves pueden escapar si la picada no las alcanza, pero caminar fuera del punto inicial no garantiza salvarlas. El jugador puede capturarlas, protegerlas con espantapájaros o derribar el águila durante la ventana vulnerable.

La picada roba al objetivo si termina a menos de 28 px y puede causar un punto de daño al jugador en el área de impacto. No se inicia sobre aves protegidas. Colocar protección durante el aviso o el descenso también cancela el ataque. La comprobación usa distancia geométrica, de modo que un espantapájaros recién colocado protege sin esperar un evento de entrada en Area2D.

## Escopeta y Bullet
- Una carga genera tres perdigones con pequeña dispersión.
- Alcance de 150 px, velocidad 520 px/s, enfriamiento 0.65 s.
- Los perdigones usan raycast barrido entre posición anterior y siguiente para reducir el riesgo de atravesar objetivos entre frames.
- La máscara de impacto es Predator + World = 12. No dañan pollos ni jugador. Pueden pasar sobre el agua, pero las paredes/cercas los detienen.
- Águilas en CRUISE, WARNING o RETREAT no reciben el impacto y no bloquean un disparo dirigido a otro enemigo detrás. Los disparos durante la picada sí las derriban.
- Sin munición no se generan perdigones. Reintentar restaura el suministro del nivel.

## Espantapájaros
R coloca uno a 36 px frente al jugador, si el suelo está libre. Se comparten las comprobaciones de colocación de FieldTools para agua, paredes, raíces, corral, huecos y trampas. No se permite superponer la base de dos espantapájaros.

Cada estructura protege un radio de 128 px, marcado por un círculo tenue. Esa zona no bloquea movimiento ni disparos; solo impide/cancela picadas. No espanta zorros. Dura la ronda y hay dos por defecto. El círculo grande es la zona segura, no una pared física ni una huella que bloquee cualquier colocación en todo su radio.

## Vida y esquiva
Player tiene health=5 y take_damage(). Cada golpe válido resta vida, aturde 0.35 s y concede 1.2 s de invulnerabilidad para evitar perder cinco corazones en cinco frames de contacto. Se muestra parpadeo provisional y el HUD dibuja cinco corazones llenos/vacíos.

El salto evita daño mientras is_airborne sea verdadero. Conserva las restricciones de la fase 2: no permite atravesar agua ni cercas. El guardián conserva su aturdimiento de fase 3 y no quita corazones; el daño de esta fase viene de zorros/picadas.

## Victoria y derrota
LevelData.GoalMode selecciona:
- BIRDS: ganar por cuota de aves depositadas.
- MONEY: ganar por dinero cobrado.
- EITHER: ganar por cualquiera de los dos objetivos.

La Granja usa BIRDS. No es necesario recolectar exactamente la cuota: llegar o superarla antes de acabar el tiempo gana.

Derrotas:
- Incapacitación: vida llega a cero.
- Tiempo: se agotan los segundos antes de alcanzar el objetivo.
- Pérdidas: ya no hay potencial suficiente para el objetivo activo.

El potencial se calcula a partir de las cantidades y valores iniciales de LevelData menos las pérdidas confirmadas. Incluye aves sueltas, en el saco y ya depositadas: capturar un ave no reduce la posibilidad de ganar. Para MONEY se usa también el valor perdido. En EITHER solo se pierde por imposibilidad cuando ambas vías quedan descartadas.

Un resultado es definitivo e idempotente: eventos tardíos no cambian victoria/derrota ni conceden dinero. Un depósito después de llegar a tiempo cero no cobra. Incapacitación y tiempo agotado tienen prioridad al evaluar el resultado; el objetivo debe alcanzarse a tiempo.

Al finalizar, se pausa el árbol de juego. ResultOverlay usa Process Mode Always para mantener su botón activo. Muestra salvadas, perdidas, dinero y motivo. Reintentar despausa, recarga el nivel y restaura aves, vida, reloj, dinero, munición, reparaciones y suministros. No hay botón de siguiente nivel todavía porque Nivel 2 se incorpora en fase 6.

## Arquitectura y señales
- Player conserva el movimiento. health_changed(current, maximum) notifica al nivel, que publica player_health_changed en EventBus.
- PlayerCombat controla munición, disparo y espantapájaros; no decide victoria ni mueve al jugador.
- Fox y Eagle solicitan Chicken.try_predation(cause). La entidad reclama su propia instancia y emite lost(data,cause).
- El spawner conecta lost al registro de pérdida global. La fuga mantiene escaped(data) de fase 4. Cada operación emite una sola vía de pérdida.
- GameManager es autoridad de contadores, reloj y resultado. finished(won,reason) comunica al nivel cuándo mostrar el resumen y pausar.
- ThreatDirector solo programa y limita oleadas; la IA vive dentro de Fox/Eagle.
- Para crear aves desde otro spawner, conectar tanto escaped como lost. No borrar aves con queue_free desde mecánicas de juego: usar try_capture/try_escape/try_predation para mantener los contadores coherentes.

## Jerarquías exactas nuevas
### Fox.tscn
```
Fox (CharacterBody2D, fox.gd, grupos predators/foxes)
└── Feet (CollisionShape2D, círculo radio 8)
```
El dibujo es _draw en Fox, reemplazable cuando se pula el arte.

### Eagle.tscn
```
Eagle (CharacterBody2D, eagle.gd, grupos predators/eagles)
├── Target (CollisionShape2D, círculo radio 13)
├── Shadow (Polygon2D)
│   └── Warning (Label)
└── Art (Node2D, eagle_art.gd, Z=10)
```
Target representa el punto de impacto de un disparo; la vulnerabilidad la valida la IA. Art usa altura visual, sin mover la sombra fuera del suelo.

### Bullet.tscn
```
Bullet (Area2D, bullet.gd, capa Projectile)
└── Shape (CollisionShape2D, círculo radio 1)
```
Monitoring/Monitorable desactivados: el impacto lo resuelve el raycast barrido, no eventos de área. La forma mantiene una escena válida y la capa reserva la identidad física del proyectil.

### Scarecrow.tscn
```
Scarecrow (Area2D, scarecrow.gd, grupo scarecrows)
└── Shape (CollisionShape2D, círculo radio 128)
```
La zona no se configura como barrera de mundo. El dibujo es provisional en _draw.

### Player acumulativo
```
Player (CharacterBody2D, player.gd)
├── Shadow
├── VisualPivot
│   └── FarmerVisual
├── GroundShape
├── Camera2D
├── Sack
├── CaptureController
├── FieldTools
└── PlayerCombat (Node, player_combat.gd)
```

### Nivel y HUD
Farm conserva Terrain, Depth, WorldCollision, CoopArea, SpawnPoints y HUD. Agrega:
```
Farm
├── ThreatDirector (Node, threat_director.gd)
└── ResultOverlay (CanvasLayer, result_overlay.gd, Always)
    └── Panel (Panel)
        ├── Title (Label)
        ├── Reason (Label)
        ├── Summary (Label)
        └── Retry (Button)
```
HUD agrega Health, Clock y Combat (Label). La lista exacta de todos los nodos guardados está en JERARQUIA_NIVEL_FASE5.txt. Aves, zorros, águilas, perdigones, trampas y espantapájaros se añaden dinámicamente a Depth: se inspeccionan en el árbol Remoto al ejecutar.

## Colisiones de fase 5
| Capa | Bit | Uso |
|---|---:|---|
| Player | 1 | Granjero |
| Chicken | 2 | Aves |
| Predator | 4 | Zorros y proyección de águilas |
| World | 8 | Cercas, edificios y obstáculos sólidos |
| Water | 16 | Agua |
| BridgeReserved | 32 | Reserva sin barrera |
| Zones | 64 | Corral/fugas |
| Projectile | 128 | Perdigones |
| LowObstacle | 256 | Raíz sorteable |
| PlayerGapBarrier | 512 | Bloqueo del jugador en huecos |
| TrapZones | 1024 | Trampas |
| ScarecrowZone | 2048 | Protección aérea |

Player mantiene máscara 792. Chicken y Fox, 280. Eagle, 0 (vuelo). Raycast de disparo, 12. Las comprobaciones de robo/contacto del zorro exigen línea libre contra 280. La protección aérea usa geometría y grupo, no colisión contra cuerpos.

## Código completo
Incluido en scripts/, autoload/, scenes/ y resources/:
- entities/fox.gd: selección de concentraciones, patrulla, robo, daño y disparo.
- entities/eagle.gd + eagle_art.gd: estados, aviso, picada y vulnerabilidad.
- entities/bullet.gd: proyectil barrido y exclusión de águilas invulnerables.
- entities/scarecrow.gd: radio seguro y visual provisional.
- entities/player_combat.gd: recursos de combate y colocación.
- levels/threat_director.gd: tiempos, manadas/parvadas y límites.
- ui/result_overlay.gd: resumen y reintento.
- autoload/game_manager.gd: objetivos, potencial, reloj y resultado.
- player.gd, chicken.gd, bait_trap.gd, field_tools.gd, phase2_hud.gd y phase3_level.gd: integración acumulativa.
- resources/level_data.gd: datos de oleadas y suministros; en este proyecto su ruta completa es scripts/resources/level_data.gd.

Los nombres phase2_hud y phase3_level son históricos; sus archivos son las versiones acumulativas actuales.

## Ajustes opcionales del editor
No hay pasos obligatorios para montar la fase. Para probar valores:
- resources/levels/farm.tres: round_seconds, goal_mode, bird_quota, money_goal, ammunition, scarecrow_supply, first_fox_seconds, first_eagle_seconds, fox_interval, eagle_interval, tamaños y máximos de oleada, predators_enabled.
- Player.tscn → Player: max_health e invulnerability_seconds; mantener cinco corazones para el HUD solicitado.
- Fox.tscn → Fox: speed y steal_distance.
- Eagle.tscn → Eagle: warning_seconds, dive_seconds, flight_speed.
- Scarecrow.tscn → Scarecrow: safe_radius.
- Bullet.tscn → Bullet: speed y max_distance.

Al reducir intervalos para probar, mantener los máximos de población. Las posiciones de aparición del tutorial y el área válida de colocación siguen diseñadas para 1280×768; al construir Nivel 2 se adaptarán a su LevelData.

## Prueba manual (recomendado)
1. F5: comprobar cinco corazones, 03:00, ocho cargas y dos espantapájaros.
2. Capturar y depositar como antes. Esperar al menos 12 s para ver la primera manada y 25 s para la primera parvada.
3. Interceptar un zorro: el contacto quita un corazón, pero no todos instantáneamente. Saltar debe evitar el golpe. Orientarse y pulsar F para detenerlo.
4. Observar una sombra con !. Durante el aviso el águila es invulnerable; disparar mientras desciende debe derribarla. Una picada no defendida puede robar un ave.
5. R sobre suelo libre cerca de aves: aparece círculo seguro. Las águilas no deben picar dentro; zorros siguen siendo peligrosos.
6. Depositar ocho antes de tiempo: victoria y resumen. Reintentar: todo vuelve a su estado inicial, incluidos huecos de cerca abiertos.
7. Para probar derrota por tiempo, cambiar temporalmente round_seconds a 10 en farm.tres, ejecutar y esperar. Restaurar a 180 después.
8. Para probar vida cero, dejar que un zorro contacte varias veces respetando la invulnerabilidad. Para probar pérdidas, permitir más de cuatro pérdidas con cuota ocho y doce aves iniciales.
9. Confirmar que el botón Reintentar funciona con el mundo pausado y que Depurador no muestra errores.

## Verificación incluida
Godot 4.4.1 estable para Linux, importación y ejecución real en modo headless. No se ha ejecutado Godot 4.7.2 ni se ha hecho revisión gráfica completa del nivel en este entorno.

- pruebas_fase5.txt: 62 comprobaciones de combate, salud, protección, oleadas, objetivo de aves/dinero/alternativo, tiempo, pérdidas y reintento.
- regresion_fase2.txt: 26 comprobaciones de movimiento, estamina, salto y cámara.
- regresion_fase3.txt: 37 comprobaciones de IA, saco y depósito.
- regresion_fase4.txt: 41 comprobaciones de red, carnada, fugas y reparación.

Las regresiones previas desactivan las oleadas para aislar sus mecánicas; las pruebas de fase 5 invocan el director y escenas de depredadores reales. Algunos casos fijan las aves en posición para aislar daño e inventario. También hay una prueba de picada que alcanza un ave móvil y otra de proyectiles reales contra águila en descenso.

Para repetir:
```
Godot --headless --path RUTA --editor --import --quit
Godot --headless --path RUTA --script res://tests/phase5_test.gd --fixed-fps 60
Godot --headless --path RUTA --script res://tests/phase4_test.gd --fixed-fps 60
Godot --headless --path RUTA --script res://tests/phase3_test.gd --fixed-fps 60
Godot --headless --path RUTA --script res://tests/phase2_test.gd --fixed-fps 60
```

En Windows sustituir Godot por la ruta al ejecutable de consola y entrecomillar las rutas con espacios.

## Siguiente fase, previa confirmación
Menú principal, pausa/ajustes, pantallas finales con navegación, controles táctiles, Nivel 2 y plantilla de niveles. El arte sigue pendiente de pulido.
