# PESCA POLLOS — Fase 4
TecNM Mérida · Tópicos Avanzados de Programación

## Entrega acumulativa
Incluye todo lo funcional de fases 1–3, más fugas, cercas reparables, red y carnada. Se conserva el terreno y el granjero provisionales según lo acordado. No se ha trabajado aún el pulido visual.

Las fugas ya cuentan como pérdidas permanentes de la partida. Las condiciones de victoria/derrota por cuota imposible, tiempo o vida se incorporan en fase 5. En esta fase perder aves no abre todavía una pantalla de derrota.

## Importar y abrir
1. Extraer PESCA_POLLOS_Fase_4.zip en una carpeta nueva.
2. Abrir Godot → Administrador de proyectos → Importar.
3. Elegir project.godot dentro de PESCA_POLLOS_Fase_4.
4. Importar y editar; esperar la importación y pulsar F5.

No hay conexiones ni configuración obligatoria que hacer manualmente en el editor. Las fases anteriores no se mezclan copiando scripts: este ZIP es el proyecto completo.

## Controles
| Acción | Teclado | Mando configurado |
|---|---|---|
| Mover | WASD / flechas | Stick izquierdo / cruceta |
| Correr | Shift | Pulsar stick izquierdo |
| Saltar | Espacio | B / botón 1 |
| Capturar | E | A / botón 0 |
| Usar red | Q | X / botón 2 |
| Colocar carnada | T | Y / botón 3 |
| Reparar | Mantener C junto al hueco | Pendiente de asignación |

Q actúa hacia la última dirección a la que mira el granjero. Moverse hacia el ave antes de usarla permite apuntar. Red y carnada no añaden aves directamente al saco: permiten acercarse y embolsarlas con E. El depósito sigue siendo automático en el corral.

## Red de mano
- Alcance 80 px; arco frontal de aproximadamente 97 grados.
- Inmoviliza durante 2.8 s, sin dañar.
- Enfriamiento de 0.8 s; no consume munición ni carnada.
- Puede alcanzar varias aves dentro del arco; no atraviesa paredes, agua, raíces o la barrera del hueco.
- No se activa durante salto ni aturdimiento.
- Una marca # identifica el ave retenida. Un arco visual representa provisionalmente la red en manos del granjero.
- Capturar con E sigue requiriendo proximidad, línea libre y espacio en el saco.

## Trampas de carnada
Se entregan tres por partida. T coloca una trampa 36 px frente al granjero; una colocación inválida no consume carnada. No se permiten en agua, cuerpos del mundo, raíces, corral, huecos, fuera del área válida o encima de otra trampa.

Una trampa disponible atrae aves en calma a un radio de 140 px con línea libre. Si se asustan, la huida tiene prioridad. Al entrar en su círculo de 13 px, una única ave queda retenida. También puede retener un ave asustada que atraviese físicamente la trampa.

Una vez retenida, el ave no huye ni embiste. El jugador debe acercarse y pulsar E; la trampa entonces se consume. El ave sigue ocupando una plaza normal del saco y solo cobra al depositarla en el corral. Si el saco está lleno, permanece retenida. Tres es el suministro total de esta partida, no un límite de tres trampas simultáneas. Reiniciar el proyecto/la escena restaura el suministro; los menús de reintento llegan en fase 6.

## Huecos y reparación
Hay dos huecos en la cerca sur:
- Oeste: centro (320,759), abertura x=288…352.
- Este: centro (992,759), abertura x=960…1024.

Se quitaron los tramos visuales y se dividió el collider sur continuo en tres cuerpos. Los pollos pueden cruzar las aberturas. Un área detecta el paso de un pollo en ALERT al alcanzar y=759: el ave sale de la escena y se suma una pérdida, sin dinero. Aves en calma no se pierden al tocar esa área; retenidas por red o trampa tampoco se consumen mientras están inmovilizadas.

El jugador tiene una barrera específica en cada abertura para no abandonar el mapa. No se trata de una pared invisible que también bloquee a las aves: las capas son distintas.

Mantener C a 58 px o menos durante 1.2 s repara gratuitamente el hueco. Soltar C, alejarse, saltar o estar aturdido cancela el progreso. Si hay un cuerpo dentro del tramo que va a cerrarse, espera a que quede libre. Al completar, se activa un collider World, se dibuja la cerca cerrada y se desactiva la fuga. La reparación dura esta partida; no se guarda en disco todavía.

## Jerarquías exactas nuevas
### FenceGap.tscn
```
FenceGap (Area2D, fence_gap.gd, grupo fence_gaps)
├── Trigger (CollisionShape2D, 64×36)
├── PlayerBarrier (StaticBody2D, capa 512)
│   └── Shape (CollisionShape2D, 64×18)
├── RepairedFence (StaticBody2D, capa 0 → 8 al reparar)
│   └── Shape (CollisionShape2D, 64×18)
└── Sign (Label)
```
Los dos FenceGap son instancias hijas de Farm/Depth, para compartir profundidad. El signo y el dibujo son provisionales; no se generó arte externo.

### Trap.tscn
```
Trap (Area2D, bait_trap.gd, grupo bait_traps)
└── Shape (CollisionShape2D, círculo radio 13)
```
Trap dibuja su base y carnada con _draw. Se añade dinámicamente a Depth. Tiene estados READY, OCCUPIED y SPENT. Se libera tras capturar el ave retenida. Si se destruye antes por retirada/cambio de escena, libera su ave para no dejarla bloqueada.

### Player.tscn, acumulativo
```
Player (CharacterBody2D, player.gd)
├── Shadow (Polygon2D)
├── VisualPivot (Node2D)
│   └── FarmerVisual (Node2D, farmer_visual.gd)
├── GroundShape (CollisionShape2D)
├── Camera2D
├── Sack (Node, chicken_sack.gd)
├── CaptureController (Node, capture_controller.gd)
└── FieldTools (Node, field_tools.gd)
```
FieldTools recibe InputMap, comunica feedback al HUD y solicita inmovilización/reparación. No modifica el dinero ni inserta aves en el saco. Player sigue dedicado a física y movimiento.

### Chicken.tscn, acumulativo
```
Chicken (CharacterBody2D, chicken.gd)
├── Shadow (Polygon2D)
├── AnimatedSprite2D
├── Feet (CollisionShape2D)
├── Detection (Area2D)
│   └── Shape (CollisionShape2D)
├── Alert (Label)
└── Restrained (Label)
```
El pollo mantiene sus estados CALM/ALERT; red y retención son condiciones ortogonales. No se crean cuatro variantes de escena ni cuatro IA duplicadas.

### Nivel y HUD
La jerarquía completa de nodos guardados está en JERARQUIA_NIVEL_FASE4.txt. Trampas y aves aparecen dinámicamente y se pueden inspeccionar en el árbol Remoto.

Farm/WorldCollision/South se sustituyó por SouthA, SouthB y SouthC. En Depth se agregan FenceGapWest y FenceGapEast. HUD añade Tools y Repair; Score muestra ahora aves a salvo, perdidas y saldo. El resto de la estructura de fase 3 se conserva.

## Contrato de colisiones
| Capa | Máscara/bit | Uso |
|---|---:|---|
| 1 Player | 1 | Granjero |
| 2 Chicken | 2 | Aves |
| 3 Predator | 4 | Reservado para fase 5 |
| 4 World | 8 | Mundo y tramo de cerca reparado |
| 5 Water | 16 | Agua |
| 6 BridgeReserved | 32 | Reserva semántica; no barrera |
| 7 Zones | 64 | Corral y detección de fuga |
| 8 Projectile | 128 | Reservado para fase 5 |
| 9 LowObstacle | 256 | Raíz sorteable con salto |
| 10 PlayerGapBarrier | 512 | Evita salir al jugador, permite pasar aves |
| 11 TrapZones | 1024 | Identifica trampas para evitar superposición |

Máscara Player: 8+16+256+512 = 792. Máscara Chicken: 8+16+256 = 280. El salto sigue quitando exclusivamente el bit 256: no permite saltar fuera del mapa. Trigger de fuga y Trap detectan Chicken mediante máscara 2. RepairedFence es capa 0 mientras está abierto y capa World=8 tras repararse.

## Flujo de eventos y protección contra duplicaciones
- FarmChicken usa is_claimed tanto en try_capture() como try_escape(). La primera operación válida reclama la instancia; las siguientes fallan.
- La captura mantiene el flujo hacia Sack y CoopArea de fase 3.
- Una fuga emite escaped(data) localmente. phase3_level.gd conecta cada ave del spawner y traduce ese evento a EventBus.chicken_lost. GameManager suma exactamente una pérdida y emite score_changed. La entidad no depende directamente de un autoload.
- Si se crean aves desde otro spawner, conectar también su señal escaped al manejador del nivel; no emitir simultáneamente la pérdida desde dos sistemas.
- La trampa marca OCCUPIED después de retener un ave. try_hold() rechaza aves reclamadas o ya retenidas, evitando dos propietarios.
- Red y trampa no cobran, no guardan copias de nodos destruidos y no capturan a distancia. Dinero solo al depositar.
- La reparación espera una huella libre y activa la colisión de forma diferida para no modificar física durante una consulta.

## Código completo incluido
- scripts/entities/field_tools.gd: red frontal, colocación válida, suministros y reparación sostenida.
- scripts/entities/bait_trap.gd: atracción disponible, retención y ciclo de vida de trampa.
- scripts/entities/fence_gap.gd: fuga por cruce y reparación segura.
- scripts/entities/chicken.gd: retención, red, atracción de carnada y reclamo único de fuga/captura.
- scripts/levels/phase3_level.gd: conexión de la señal de fuga de cada ave.
- autoload/game_manager.gd: registro de pérdidas.
- scripts/ui/phase2_hud.gd: HUD acumulativo de fases 2–4.
- scripts/entities/farmer_visual.gd: representación de red.
- project.godot y escenas: capas y nodos completos.

Los nombres phase2_hud y phase3_level son históricos; contienen las implementaciones acumulativas actuales. No es necesario copiar código de documentos anteriores.

## Ajustes opcionales del editor
Ninguno es obligatorio para ejecutar. Para experimentar:
- Player.tscn → FieldTools: alcance/arco/duración/enfriamiento de red, carnadas y alcance de reparación.
- FenceGap.tscn → Repair Seconds: tiempo para reparar; Sign y _draw controlan el aspecto provisional.
- Trap.tscn → Lure Radius: radio de atracción; Shape controla la retención.
- La colocación de trampas limita el área al mapa actual de 1280×768. Al construir Nivel 2 deberá usar los límites de su LevelData en lugar de estos límites del tutorial.
- Evitar mover un hueco sin modificar también las secciones del collider sur y los sprites de cerca correspondientes. escape_line_y permite desplazar el umbral de cruce respecto a su centro.

## Prueba manual sugerida
1. Perseguir una ágil, orientarse hacia ella y pulsar Q. Acercarse durante la inmovilización y pulsar E; depositarla en el corral.
2. Pulsar T en suelo libre y alejarse más del radio de alarma de una gallina cercana. Observar que camine hacia la carnada y quede retenida. Volver y capturarla.
3. Intentar T en agua o en el corral: debe informar el rechazo sin consumir carnada.
4. Ir al borde sur oeste (x≈320) o este (x≈992). Empujar una gallina asustada hacia la abertura; al cruzarla aumenta Perdidas y no vuelve a aparecer.
5. Mantener C cerca de uno de los huecos: ver Reparando y cerca cerrada al terminar. Comprobar que otro pollo ya no puede cruzarla.
6. Soltar C antes de terminar, o alejarse: el progreso se cancela. El granjero nunca debe salir del mapa.
7. Revisar que captura, límite de seis, depósito, puente, salto y estamina continúen funcionando.

## Verificación ejecutada
Godot 4.4.1 Linux, importación real y pruebas headless. Se incluyen registros:
- pruebas_fase4.txt: integración de red, carnada, retención, fuga, reparación y HUD.
- regresion_fase3.txt: IA, captura, inventario y depósito.
- regresion_fase2.txt: movimiento, estamina, salto y límites.

Los tests de inventario usan aves inmóviles para aislar sus verificaciones; los de atracción y física las dejan activas. La revisión visual y la ejecución específica en Godot 4.7.2 quedan pendientes en el equipo del usuario.

Para repetir, sustituyendo Godot y RUTA por el ejecutable y la carpeta del proyecto:
```
Godot --headless --path RUTA --editor --import --quit
Godot --headless --path RUTA --script res://tests/phase4_test.gd --fixed-fps 60
Godot --headless --path RUTA --script res://tests/phase3_test.gd --fixed-fps 60
Godot --headless --path RUTA --script res://tests/phase2_test.gd --fixed-fps 60
```

## Siguiente fase
Solo después de confirmar: Fox y Eagle, escopeta, espantapájaros, vida y condiciones de victoria/derrota. Arte sigue pendiente para la etapa de pulido acordada.
