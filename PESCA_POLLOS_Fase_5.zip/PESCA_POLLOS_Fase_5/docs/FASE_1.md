> Documento histórico de fase 1. Para esta entrega leer FASE_2.md y pruebas_fase2.txt.

# PESCA POLLOS — Fase 1
Proyecto universitario, Tópicos Avanzados de Programación, TecNM Mérida.

## Alcance y compatibilidad
Base para Godot 4.x con TileMapLayer (4.3+). Versión declarada por el usuario: 4.7.2. No hay binario Godot instalado en este entorno: no se afirma ejecución ni certificación en esa versión. Se entrega laboratorio para verificar en el editor. No incluye gameplay de fases posteriores.

## Abrir y probar
1. Extraer todo el ZIP y abrir Godot → Importar → project.godot.
2. Esperar la importación de PNG y registro de clases Resource.
3. Ejecutar F6 sobre scenes/ui/atlas_lab.tscn o F5.
4. Debe aparecer el atlas, sin títulos de la referencia, y la dirección debe cambiar con WASD, flechas o stick. La diagonal debe medir como máximo 1.
5. Mantener Shift, Espacio, E, Q, T, F, C, R y Esc: los nombres de acciones aparecen a la derecha. Esta pantalla no mueve un jugador.
6. Verificar que Salida muestre FASE 1 y el panel Depurador no tenga errores.
7. Abrir resources/tilesets/farm_tileset.tres: debe mostrar celdas de 32 px. Los sprites de objetos NO tienen colisiones automáticas.
8. Abrir resources/levels/farm.tres: título, cuota, tiempo y cantidad son editables sin tocar scripts.

No hay pasos manuales obligatorios para montar esta fase. InputMap, autoloads, capas y configuración ya se encuentran en project.godot. Para comprobar píxeles ampliar la ventana a 1280×720; escalas enteras pueden dejar bandas negras.

## Jerarquía exacta
atlas_lab.tscn:
```
AtlasLab (Node2D, atlas_lab.gd)
├── Backdrop (ColorRect)
├── Title (Label)
├── Preview (Sprite2D)
├── Status (Label)
└── Help (Label)
```
level_template.tscn, estructura vacía reservada para fase 2:
```
LevelTemplate (Node2D)
├── Ground (TileMapLayer)
├── Paths (TileMapLayer)
├── Water (TileMapLayer)
├── Bridge (TileMapLayer)
├── Depth (Node2D, Y-Sort)
│   ├── Props (Node2D, Y-Sort)
│   └── Actors (Node2D, Y-Sort)
├── WorldCollision (Node2D)
├── Zones (Node2D)
└── SpawnPoints (Node2D)
    └── PlayerSpawn (Marker2D)
```
Cada autoload es un Node con su script. Los servicios de audio y guardado solo declaran contratos; se implementan en fase 7. SceneManager valida rutas; fade pendiente de fase 6.

## Colisiones: contrato para las siguientes fases
| Capa | Bit/máscara | Uso |
|---|---:|---|
| 1 Player | 1 | Cuerpo del granjero |
| 2 Chicken | 2 | Cuerpo de aves |
| 3 Predator | 4 | Depredadores |
| 4 World | 8 | Cercas, edificios, rocas y árboles |
| 5 Water | 16 | Agua no transitable |
| 6 BridgeReserved | 32 | Reserva semántica: NO barrera física |
| 7 Zones | 64 | Corral, detección y fuga |
| 8 Projectile | 128 | Proyectiles |

Máscara prevista Player y Chicken: World + Water = 24. El contacto de daño se detectará con áreas, evitando que los cuerpos se bloqueen mutuamente. El puente se resuelve dejando sin colisión las celdas de agua debajo del paso: dibujarlo encima no anula una colisión existente. Zone detecta Player/Chicken mediante máscaras 1/2. No se activa física en el laboratorio.

## Decisiones
640×360, filtro nearest, viewport y escala entera. Snap de transformaciones; no se combina con snap de vértices. Renderer Compatibility para una base sencilla de PC/Android; exportaciones y pruebas móviles en fase 7.

El estado de ronda pertenece a GameManager; ChickenData y LevelData solo describen configuración. Las entidades reutilizables tendrán señales locales y se usará EventBus para eventos que realmente cruzan sistemas. No se crean máquinas de estados vacías antes de tener comportamiento.

TileMapLayer separa cada capa; Props y Actors comparten profundidad mediante la cadena Y-Sort. En fase 2 se situará el origen visual de cada objeto en los pies y se comprobará con el jugador por delante y detrás.

## Arte y límites
La referencia original se conserva intacta. La extracción asistida puede modificar detalles del dibujo; no equivale a recuperar los sprites fuente. El atlas es una adaptación y requiere aprobación visual. No se inventa una secuencia de caminar a partir de imágenes ambiguas: las aves recortadas se documentan como poses, no animaciones completas. Árboles y edificios usan celdas múltiples para evitar comprimirlos a un único tile. El mapa de ejemplo no se usa como fondo jugable.

Ver ATLAS.csv para regiones exactas del atlas final y procedencia. No hay autotiling ni terrenos configurados: los bordes de agua/camino deben revisarse al construir el nivel. Los fotogramas de captura, aturdimiento, granjero, zorro y águila todavía no forman parte del arte aprobado.

## Fuentes técnicas
https://docs.godotengine.org/en/stable/classes/class_tilemaplayer.html
https://docs.godotengine.org/en/stable/tutorials/rendering/multiple_resolutions.html
https://docs.godotengine.org/en/stable/tutorials/2d/using_tilesets.html

## Siguiente fase
Solo tras confirmación: Player, estados, estamina y salto; cámara limitada; Nivel 1 con colisiones y paso transitable por puente.
