# PESCA POLLOS — Fase 3
Tópicos Avanzados de Programación · TecNM Mérida

## Alcance de esta entrega
Sobre la fase 2 se agregaron gallinas reutilizables, IA de calma/alerta, cuatro variantes, captura directa, saco de seis aves, depósito automático y marcador. El aspecto del granjero y el terreno se conserva provisional por decisión del usuario. No se está presentando esta fase como un pulido de arte.

No hay todavía fugas, reparaciones, red o trampas (fase 4), zorros/águilas, vida, temporizador ni pantallas de victoria/derrota (fase 5/6). Llegar a la cuota de ocho actualiza el HUD y permite seguir practicando: no termina la ronda todavía.

## Abrir y ejecutar
1. Extraer PESCA_POLLOS_Fase_3.zip en una carpeta nueva.
2. Administrador de proyectos de Godot → Importar → seleccionar project.godot en PESCA_POLLOS_Fase_3.
3. Importar y editar; esperar importación y pulsar F5.
4. Aparecen doce aves en La Granja.

El proyecto está configurado por archivos: no requiere crear nodos ni conectar señales manualmente en el editor.

## Controles y recorrido de prueba
- WASD/flechas/stick: mover; Shift/stick izquierdo pulsado: correr; Espacio/B: saltar.
- E/A: capturar la gallina más cercana a un máximo de 30 px, con línea de visión libre.
- No se captura mientras se salta ni durante aturdimiento.
- El arco amarillo del granjero muestra el gesto provisional de captura durante 0.16 s.
- Llevar las aves al **rectángulo verde del corral central**, frente al edificio. Entrar por el hueco del sur: el saco se descarga solo, se suman las aves y se cobra su valor.
- Las seis estándar son blancas; ágiles azuladas; guardianes anaranjados; la rara dorada.
- F8 sigue disponible para probar el estado Aturdido en debug.

### Verificación manual
1. Alejarse de un pollo: deambula y alterna con pausas de picoteo/idle. Acercarse: aparece ! y huye. Al alejarse regresa a calma tras 0.8 s sin amenaza.
2. Capturar con E. El saco sube, pero el saldo y las aves a salvo aún no cambian.
3. Capturar seis: al intentar otra captura aparece Saco lleno y la séptima ave sigue en el mapa.
4. Entrar en el área verde: saco vuelve a cero; aves a salvo y saldo aumentan según las variantes depositadas.
5. Permanecer dentro: no debe volver a sumar. Si se captura otra ave estando dentro, también se descarga automáticamente.
6. Buscar un guardián: puede cargar y aturdir; saltar permite evitar el aturdimiento de contacto. Las ágiles son más rápidas que el granjero y requieren acorralarlas; red y trampas llegan en fase 4.
7. Probar E lejos de las aves o con una pared entre ambos: no debe capturar.
8. Revisar Depurador: cero errores. La fase 1 sigue accesible con F6 sobre atlas_lab.tscn.

## Recursos de variantes
| Recurso | Cantidad | Calma px/s | Alerta px/s | Valor | Color |
|---|---:|---:|---:|---:|---|
| standard.tres | 6 | 22 | 75 | 10 | Blanco |
| wild.tres | 3 | 30 | 118 | 20 | Azulado |
| guardian.tres | 2 | 20 | 95 | 25 | Naranja |
| rare.tres | 1 | 24 | 85 | 60 | Dorado |

Todos utilizan chicken.tscn y el mismo SpriteFrames. El color se aplica por modulate; no se generó arte nuevo. ChickenData.aggression > 0 habilita la carga del guardián. Cada guardián espera inicialmente 1.8 s, luego tiene enfriamiento de 2.5 s entre cargas; el aturdimiento dura 0.7 s.

resources/levels/farm.tres contiene tipos y cantidades por índice; cuota 8 y tiempo configurado 180, aunque el temporizador no se activa hasta fase 5. Los puntos iniciales están en phase3_level.gd. Para añadir más de doce aves es necesario añadir puntos a POINTS; un assert evita generar posiciones arbitrarias dentro de edificios. Los recursos comparten configuración, nunca el estado de IA.

## Jerarquías exactas
### Chicken.tscn
```
Chicken (CharacterBody2D, chicken.gd, grupo chickens)
├── Shadow (Polygon2D)
├── AnimatedSprite2D (chicken_frames.tres)
├── Feet (CollisionShape2D, círculo radio 5)
├── Detection (Area2D)
│   └── Shape (CollisionShape2D, círculo radio 84)
└── Alert (Label)
```
Capa Chicken=2; máscara World + Water + LowObstacle = 280. Detection sin capa y máscara Player + Predator = 5. Las aves no se bloquean mutuamente ni bloquean el cuerpo del jugador; el guardián aturde mediante comprobación de distancia. La forma de detección se crea por instancia para no modificar recursos compartidos.

### Player.tscn (acumulativo)
```
Player (CharacterBody2D, player.gd, grupo player)
├── Shadow (Polygon2D)
├── VisualPivot (Node2D)
│   └── FarmerVisual (Node2D, farmer_visual.gd)
├── GroundShape (CollisionShape2D)
├── Camera2D
├── Sack (Node, chicken_sack.gd)
└── CaptureController (Node, capture_controller.gd)
```
CaptureController busca aves del grupo chickens, filtra por radio y línea de visión con World/Water (máscara 24) y elige la más cercana. Esto evita capturar a través de cercas o edificios. Enfriamiento de 0.22 s entre intentos. No depende del dibujo ni del HUD.

### CoopArea.tscn
```
CoopArea (Area2D, coop_area.gd)
├── Floor (Polygon2D)
├── Shape (CollisionShape2D, rectángulo 130×54)
└── Sign (Label)
```
Capa Zones=64; máscara Player=1. En Farm se ubica en (640,329), delante de Depth, de forma que el suelo del depósito no se dibuje encima de los actores. Comprueba ocupantes cada tick físico: también funciona al capturar mientras el granjero permanece dentro.

### Nivel y HUD
La jerarquía previa se conserva. Farm ahora lleva phase3_level.gd; CoopArea es un hijo directo de Farm y las aves aparecen como hijos directos de Depth para compartir Y-Sort con jugador y props. La lista completa guardada está en JERARQUIA_NIVEL_FASE3.txt; las doce gallinas se añaden al ejecutar, y se ven en el árbol Remoto.

HUD conserva Panel/Stamina, Panel/State, Panel/Jump y Controls. Se agregan:
```
HUD (CanvasLayer, phase2_hud.gd actualizado)
├── Panel (estructura de fase 2)
├── Controls (Label)
├── Bag (Label)
├── Score (Label)
└── Feedback (Label)
```

## Flujo y decisiones de diseño
1. E llama capture_nearest() en CaptureController.
2. Chicken.try_capture() verifica disponibilidad y marca la instancia antes de emitir señales; Sack.try_add() verifica capacidad antes de guardar ChickenData.
3. La gallina sale del grupo, se oculta y queue_free libera su nodo. El saco conserva el Resource, no referencias a nodos destruidos.
4. CoopArea toma y vacía el saco ANTES de emitir deposited y EventBus.chicken_deposited. Permanecer en la zona no repite depósitos.
5. GameManager escucha el evento global y actualiza saved_chickens y money. Su señal score_changed actualiza el HUD. El saco y el controlador usan señales locales.

El depósito suma el valor individual de cada variante. Capturar no entrega dinero. No se duplican aves ni recompensas al repetir la acción o permanecer dentro del corral.

## IA y límites actuales
CALM usa direcciones aleatorias con semilla por posición inicial y pausas. ALERT detecta Player o un cuerpo del grupo predators (preparación para fase 5), conserva 0.8 s la última amenaza y huye en sentido opuesto. Se sondean varias direcciones con raycasts para evitar obstáculos; move_and_slide garantiza la colisión física. Es dirección local reactiva, no navegación global: al construir mapas laberínticos deberá evolucionar hacia navegación o un campo de flujo.

AnimatedSprite2D ofrece idle, walk_down, walk_up, walk_left y walk_right. Las secuencias de dos poses reutilizan los recortes disponibles de la referencia: son animaciones provisionales y algunas direcciones no corresponden a fotogramas originales completos. Se mejorarán junto con el terreno y el granjero cuando se aborde el arte.

## Archivos nuevos y modificados
Código completo incluido en scripts/, autoload/ y tests/:
- entities/chicken.gd: IA, animación y captura atómica.
- entities/chicken_sack.gd: inventario y descarga.
- entities/capture_controller.gd: acción, radio, línea de visión y feedback.
- entities/coop_area.gd: detección y depósito.
- levels/phase3_level.gd: configuración y apariciones.
- ui/phase2_hud.gd: HUD acumulativo por señales.
- autoload/game_manager.gd: marcador y evento de depósito.
- entities/farmer_visual.gd: gesto provisional de captura.
Escenas completas en scenes/entities/ y scenes/levels/farm.tscn. SpriteFrames y variantes en resources/chickens/.

## Pruebas reproducibles
Importación y ejecución headless en Godot 4.4.1 Linux. pruebas_fase3.txt contiene los resultados de integración; regresion_fase2.txt verifica que movimiento, estamina, salto y colisiones sigan funcionando. La ejecución en Godot 4.7.2 y la revisión visual quedan por confirmar en el equipo del usuario.

```
Godot --headless --path RUTA --editor --import --quit
Godot --headless --path RUTA --script res://tests/phase3_test.gd --fixed-fps 60
Godot --headless --path RUTA --script res://tests/phase2_test.gd --fixed-fps 60
```
Las pruebas simulan entradas y usan las escenas reales: distribución y posición válida de spawns, alerta/huida, vuelta a calma, guardián, alcance, pared, capacidad, captura duplicada, dinero antes/después del depósito, depósito único y captura dentro del corral. En los casos de inventario se inmovilizan aves para aislar los comportamientos; el test de IA las deja activas.

## Ajustes opcionales en el editor
- Chicken.tscn → Chicken: Detection Radius.
- resources/chickens/*.tres: velocidades, reward, aggression y tint.
- Player.tscn → CaptureController: Capture Range.
- Player.tscn → Sack: Capacity; mantener seis para el diseño solicitado.
- CoopArea.tscn → Shape: tamaño de depósito. Mover Floor y Sign si cambia su tamaño.
- Farm.tscn → CoopArea: posición. Mantener libre la entrada sur.

## Siguiente fase, previa confirmación
Huecos de fuga, cercas reparables, red/lazo y trampas de carnada. El pulido de arte queda pendiente según lo acordado.
