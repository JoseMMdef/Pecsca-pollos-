# Verificación de fase 5

Godot 4.4.1 Linux, ejecución headless.

- pruebas_fase5.txt: 62 comprobaciones aprobadas.
- regresion_fase4.txt: 41 comprobaciones aprobadas.
- regresion_fase3.txt: 37 comprobaciones aprobadas.
- regresion_fase2.txt: 26 comprobaciones aprobadas.

Total: 166 aprobadas; cero fallos. No se ha probado la versión 4.7.2 ni Android. La revisión gráfica queda pendiente en el equipo del usuario.
