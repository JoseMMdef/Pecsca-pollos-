# PESCA POLLOS — Fase 5
Extrae en carpeta nueva, importa project.godot y pulsa F5.
WASD/flechas: mover · Shift: correr · Espacio: esquivar · E: capturar.
Q: red · T: carnada · Mantener C: reparar · F: escopeta · R: espantapájaros.
Deposita ocho aves en el corral antes de 180 s. Zorros desde 12 s, águilas desde 25 s.
Resultado pausa la ronda y permite Reintentar. Arte provisional conservado.
Código, nodos, configuración y pruebas: docs/FASE_5.md.
