extends CanvasLayer
## HUD acumulativo: física y recolección por señales locales y marcador global.
@export var player_path: NodePath
@onready var player: FarmerPlayer = get_node(player_path)
@onready var bar: ProgressBar = $Panel/Stamina
@onready var status: Label = $Panel/State

func _ready() -> void:
    player.stamina_changed.connect(_on_stamina_changed)
    player.state_changed.connect(_on_state_changed)
    player.jump_changed.connect(_on_jump_changed)
    _on_stamina_changed(player.stamina, player.max_stamina)
    _on_state_changed(player.state_name())
    var sack: ChickenSack = player.get_node("Sack")
    sack.changed.connect(_on_bag_changed)
    player.get_node("CaptureController").feedback.connect(_on_feedback)
    GameManager.score_changed.connect(_on_score_changed)
    var tools: Node = player.get_node("FieldTools")
    tools.feedback.connect(_on_feedback)
    tools.tools_changed.connect(_on_tools_changed)
    tools.repair_progress.connect(_on_repair_progress)
    _on_tools_changed(tools.baits)
    var combat: Node = player.get_node("PlayerCombat")
    combat.changed.connect(_on_combat_changed)
    combat.feedback.connect(_on_feedback)
    GameManager.health_changed.connect(_on_health_changed)
    GameManager.clock_changed.connect(_on_clock_changed)
    _on_combat_changed(combat.ammunition, combat.scarecrows)
    _on_health_changed(player.health)
    _on_clock_changed(GameManager.remaining_seconds)
    _on_bag_changed(sack.count(), sack.capacity)
    _on_score_changed(GameManager.saved_chickens, GameManager.lost_chickens, GameManager.money)

func _on_stamina_changed(current: float, maximum: float) -> void:
    bar.max_value = maximum
    bar.value = current

func _on_state_changed(label: String) -> void:
    status.text = "Estado: " + label

func _on_jump_changed(active: bool) -> void:
    $Panel/Jump.text = "Salto: en el aire" if active else "Salto: en tierra"

func _unhandled_key_input(event: InputEvent) -> void:
    if OS.is_debug_build() and event is InputEventKey:
        if event.pressed and not event.echo and event.physical_keycode == KEY_F8:
            player.stun(1.0)

func _on_bag_changed(count: int, capacity: int) -> void:
    $Bag.text = "Pollos en saco: %d / %d" % [count, capacity]

func _on_score_changed(saved: int, lost: int, money: int) -> void:
    var goal: int = 8
    if GameManager.current_level != null:
        goal = GameManager.current_level.bird_quota
    $Score.text = "A salvo: %d / %d | Perdidas: %d | Saldo: $%d" % [saved, goal, lost, money]

func _on_feedback(message: String) -> void:
    $Feedback.text = message

func _on_tools_changed(baits_left: int) -> void:
    $Tools.text = "Carnadas: %d / 3 | Red: Q" % baits_left

func _on_repair_progress(progress: float) -> void:
    $Repair.text = "Reparando: %d%%" % int(progress * 100.0) if progress > 0.0 else ""

func _on_health_changed(current: int) -> void:
    $Health.text = "♥ ".repeat(maxi(0, current)) + "♡ ".repeat(maxi(0, 5-current))

func _on_clock_changed(seconds: float) -> void:
    var whole: int = int(ceil(seconds))
    $Clock.text = "%02d:%02d" % [whole / 60, whole % 60]

func _on_combat_changed(ammo: int, crows: int) -> void:
    $Combat.text = "Munición: %d | Espantapájaros: %d" % [ammo, crows]
