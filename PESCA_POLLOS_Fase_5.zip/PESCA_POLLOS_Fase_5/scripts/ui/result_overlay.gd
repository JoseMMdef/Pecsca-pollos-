extends CanvasLayer
## Resumen funcional de fase 5. El diseño de menús y nivel siguiente llega en fase 6.
func _ready() -> void:
    $Panel.hide()
    $Panel/Retry.pressed.connect(_retry)

func show_result(won: bool, reason: String) -> void:
    var gm: Node = get_node("/root/GameManager")
    $Panel.show()
    $Panel/Title.text = "¡VICTORIA!" if won else "DERROTA"
    $Panel/Reason.text = reason
    $Panel/Summary.text = "Aves salvadas: %d\nAves perdidas: %d\nDinero cobrado: $%d" % [gm.saved_chickens, gm.lost_chickens, gm.money]
    $Panel/Retry.grab_focus()

func _retry() -> void:
    get_tree().paused = false
    get_tree().reload_current_scene()
