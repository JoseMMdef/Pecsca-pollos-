extends Node2D
## Verificación visual de atlas y acciones, sin implementar gameplay de fase 2.
const ATLAS: Texture2D = preload("res://assets/tilesets/farm_atlas.png")
@onready var status: Label = $Status

func _ready() -> void:
    $Preview.texture = ATLAS
    var data: LevelData = load("res://resources/levels/farm.tres")
    assert(data.validation_errors().is_empty(), "LevelData no válido")
    print("FASE 1: recursos cargados. Revisa atlas y controles en pantalla.")

func _process(_delta: float) -> void:
    var direction := Input.get_vector("move_left", "move_right", "move_up", "move_down")
    var actions := PackedStringArray()
    for action in ["run", "jump", "capture", "net", "trap", "shoot", "repair", "scarecrow", "pause"]:
        if Input.is_action_pressed(action):
            actions.append(action)
    status.text = "Atlas: celdas 32 x 32\nDirección: %s\nAcciones:\n%s\n\nSin gameplay en esta fase." % [direction, "\n".join(actions)]
