extends Area2D
## Perdigón con raycast barrido: no atraviesa paredes ni daña pollos/jugador.
@export var speed: float = 520.0
@export var max_distance: float = 150.0
var direction: Vector2 = Vector2.RIGHT
var _travelled: float = 0.0

func _physics_process(delta: float) -> void:
    var distance: float = minf(speed * delta, max_distance - _travelled)
    var destination: Vector2 = global_position + direction * distance
    var query := PhysicsRayQueryParameters2D.create(global_position, destination, 12)
    var exclude: Array[RID] = []
    # Un águila invulnerable no debe bloquear un disparo dirigido al suelo.
    for attempt in range(8):
        query.exclude = exclude
        var hit: Dictionary = get_world_2d().direct_space_state.intersect_ray(query)
        if hit.is_empty():
            break
        var collider: Object = hit.collider
        if collider.has_method("receive_shot"):
            if collider.receive_shot():
                queue_free()
                return
            exclude.append(hit.rid)
        else:
            queue_free()
            return
    global_position = destination
    _travelled += distance
    if _travelled >= max_distance:
        queue_free()

func _draw() -> void:
    draw_rect(Rect2(-2, -2, 4, 3), Color("ffe7ac"))
