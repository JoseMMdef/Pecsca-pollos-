extends Node
## Captura por alcance y línea de visión. No conoce el HUD ni el corral.
signal feedback(message: String)
@export var capture_range: float = 30.0
@onready var player: FarmerPlayer = get_parent()
@onready var sack: ChickenSack = $"../Sack"
var _cooldown: float = 0.0
var _flash: float = 0.0

func _physics_process(delta: float) -> void:
    _cooldown = maxf(0.0, _cooldown - delta)
    _flash = maxf(0.0, _flash - delta)
    player.art.capturing = _flash > 0.0
    if Input.is_action_just_pressed("capture"):
        capture_nearest()

func capture_nearest() -> bool:
    if _cooldown > 0.0 or player.state == FarmerPlayer.State.STUNNED or player.is_airborne:
        return false
    _cooldown = 0.22
    if sack.count() >= sack.capacity:
        feedback.emit("Saco lleno: lleva tus aves al corral.")
        return false
    var nearest: FarmChicken = null
    var best: float = capture_range * capture_range
    for node in get_tree().get_nodes_in_group("chickens"):
        var bird := node as FarmChicken
        if bird == null or bird.is_claimed:
            continue
        var distance: float = player.global_position.distance_squared_to(bird.global_position)
        if distance <= best and _has_sight(bird):
            nearest = bird
            best = distance
    if nearest == null:
        feedback.emit("Acércate a una gallina y pulsa E.")
        return false
    if nearest.try_capture(sack):
        _flash = 0.16
        feedback.emit("¡Capturada! Llévala al corral.")
        return true
    return false

func _has_sight(bird: FarmChicken) -> bool:
    var query := PhysicsRayQueryParameters2D.create(player.global_position, bird.global_position, 24)
    return player.get_world_2d().direct_space_state.intersect_ray(query).is_empty()
