class_name FarmChicken
extends CharacterBody2D
## Reutilizable: parámetros en ChickenData; estado particular en esta instancia.
signal captured(data: ChickenData)
signal escaped(data: ChickenData)
signal lost(data: ChickenData, cause: StringName)
enum State { CALM, ALERT }
@export var data: ChickenData
@export var detection_radius: float = 84.0
var state: State = State.CALM
var is_claimed: bool = false
var _net_time: float = 0.0
var _trap_owner: Node2D
var _wander_time: float = 0.0
var _wander_direction: Vector2 = Vector2.ZERO
var _alert_memory: float = 0.0
var _last_threat_position: Vector2 = Vector2.ZERO
var _charge_time: float = 0.0
var _charge_cooldown: float = 1.8
var _charge_direction: Vector2 = Vector2.ZERO
var _rng := RandomNumberGenerator.new()
@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var detection: Area2D = $Detection

func _ready() -> void:
    if data == null:
        data = load("res://resources/chickens/standard.tres")
    _rng.seed = int(global_position.x * 371 + global_position.y * 17)
    sprite.modulate = data.tint
    # Cada instancia posee su forma: no modificar un Resource compartido.
    var circle := CircleShape2D.new()
    circle.radius = detection_radius
    $Detection/Shape.shape = circle

func _physics_process(delta: float) -> void:
    if is_claimed:
        return
    if is_instance_valid(_trap_owner):
        velocity = Vector2.ZERO
        sprite.play(&"idle")
        $Alert.visible = false
        $Restrained.visible = true
        return
    _net_time = maxf(0.0, _net_time - delta)
    $Restrained.visible = _net_time > 0.0
    if _net_time > 0.0:
        velocity = Vector2.ZERO
        sprite.play(&"idle")
        $Alert.visible = false
        return
    _charge_cooldown = maxf(0.0, _charge_cooldown - delta)
    var threat: Node2D = _nearest_threat()
    if threat != null:
        state = State.ALERT
        _alert_memory = 0.8
        _last_threat_position = threat.global_position
    else:
        _alert_memory = maxf(0.0, _alert_memory - delta)
        if _alert_memory <= 0.0:
            state = State.CALM
    if state == State.CALM:
        _wander_time -= delta
        if _wander_time <= 0.0:
            _wander_time = _rng.randf_range(0.5, 1.5)
            _wander_direction = Vector2.ZERO if _rng.randf() < 0.38 else Vector2.RIGHT.rotated(_rng.randf_range(-PI, PI))
        var bait: BaitTrap = _nearest_bait()
        var calm_direction: Vector2 = global_position.direction_to(bait.global_position) if bait != null else _wander_direction
        velocity = _steer(calm_direction) * data.calm_speed
    else:
        var away: Vector2 = (_last_threat_position.direction_to(global_position))
        if away.is_zero_approx():
            away = Vector2.RIGHT
        # El guardián carga con aviso breve y enfriamiento; no causa daño de vida.
        if data.aggression > 0.0 and threat is FarmerPlayer and _charge_cooldown <= 0.0:
            _charge_time = 0.38
            _charge_cooldown = 2.5
            _charge_direction = global_position.direction_to(threat.global_position)
        if _charge_time > 0.0:
            _charge_time = maxf(0.0, _charge_time - delta)
            velocity = _steer(_charge_direction) * data.flee_speed
            if threat is FarmerPlayer and global_position.distance_to(threat.global_position) < 19.0:
                if not threat.is_airborne:
                    threat.stun(0.7)
                _charge_time = 0.0
        else:
            velocity = _steer(away) * data.flee_speed
    move_and_slide()
    if get_slide_collision_count() > 0 and state == State.CALM:
        _wander_time = 0.0
    _animate()

func _nearest_threat() -> Node2D:
    var nearest: Node2D = null
    var best: float = INF
    for body in detection.get_overlapping_bodies():
        if body.is_in_group("player") or body.is_in_group("predators"):
            var distance: float = global_position.distance_squared_to(body.global_position)
            if distance < best:
                best = distance
                nearest = body
    return nearest

func _steer(direction: Vector2) -> Vector2:
    if direction.is_zero_approx():
        return Vector2.ZERO
    # Sondeo local, no navegación global: elegir una salida libre al bordear obstáculos.
    for angle: float in [0.0, 0.65, -0.65, 1.3, -1.3, PI]:
        var candidate: Vector2 = direction.rotated(angle)
        var query := PhysicsRayQueryParameters2D.create(global_position, global_position + candidate * 22.0, 280)
        if get_world_2d().direct_space_state.intersect_ray(query).is_empty():
            return candidate
    return Vector2.ZERO

func _animate() -> void:
    var animation_name: StringName = &"idle"
    if velocity.length() > 3.0:
        if absf(velocity.x) > absf(velocity.y):
            animation_name = &"walk_right" if velocity.x > 0.0 else &"walk_left"
        else:
            animation_name = &"walk_down" if velocity.y > 0.0 else &"walk_up"
    sprite.play(animation_name)
    sprite.speed_scale = 1.4 if state == State.ALERT else 0.8
    $Alert.visible = state == State.ALERT

func try_capture(sack: ChickenSack) -> bool:
    ## Marcar antes de emitir señales: una misma instancia nunca se captura dos veces.
    if is_claimed or sack.count() >= sack.capacity:
        return false
    is_claimed = true
    if not sack.try_add(data):
        is_claimed = false
        return false
    remove_from_group("chickens")
    hide()
    captured.emit(data)
    queue_free()
    return true

func is_trapped() -> bool:
    return is_instance_valid(_trap_owner)

func apply_net(seconds: float) -> bool:
    if is_claimed or is_trapped():
        return false
    _net_time = maxf(_net_time, seconds)
    _charge_time = 0.0
    velocity = Vector2.ZERO
    return true

func try_hold(owner_node: Node2D) -> bool:
    if is_claimed or is_trapped():
        return false
    _trap_owner = owner_node
    _charge_time = 0.0
    velocity = Vector2.ZERO
    return true

func release_from_trap(owner_node: Node2D) -> void:
    if _trap_owner == owner_node:
        _trap_owner = null

func try_escape() -> bool:
    ## Reclamo único compartido con captura: pérdida y captura no pueden duplicarse.
    if is_claimed or is_trapped() or _net_time > 0.0:
        return false
    is_claimed = true
    remove_from_group("chickens")
    hide()
    escaped.emit(data)
    queue_free()
    return true

func _nearest_bait() -> BaitTrap:
    var nearest: BaitTrap = null
    var best: float = INF
    for node in get_tree().get_nodes_in_group("bait_traps"):
        var trap := node as BaitTrap
        if trap == null or not trap.is_available():
            continue
        var distance: float = global_position.distance_squared_to(trap.global_position)
        if distance < best and distance <= trap.lure_radius * trap.lure_radius:
            var query := PhysicsRayQueryParameters2D.create(global_position, trap.global_position, 280)
            if get_world_2d().direct_space_state.intersect_ray(query).is_empty():
                nearest = trap
                best = distance
    return nearest

func try_predation(cause: StringName) -> bool:
    ## La carnada y la red inmovilizan, pero no protegen del depredador.
    if is_claimed:
        return false
    is_claimed = true
    remove_from_group("chickens")
    hide()
    lost.emit(data, cause)
    queue_free()
    return true
