class_name FarmerPlayer
extends CharacterBody2D
## Controlador top-down: la posición física representa SIEMPRE los pies.
## El salto levanta solo VisualPivot y atraviesa exclusivamente LowObstacle.
signal stamina_changed(current: float, maximum: float)
signal state_changed(label: String)
signal jump_changed(active: bool)
signal health_changed(current: int, maximum: int)
signal incapacitated

enum State { IDLE, WALKING, RUNNING, STUNNED }
const LOW_OBSTACLE_LAYER: int = 9
@export_group("Movimiento")
@export var walk_speed: float = 90.0
@export var run_speed: float = 145.0
@export var acceleration: float = 850.0
@export_group("Estamina")
@export var max_stamina: float = 100.0
@export var run_drain: float = 28.0
@export var rest_regeneration: float = 32.0
@export var walk_regeneration: float = 12.0
@export var regeneration_delay: float = 0.85
@export_group("Salto")
@export var jump_duration: float = 0.55
@export var jump_height: float = 21.0
@export var jump_cooldown: float = 0.15

@export var max_health: int = 5
@export var invulnerability_seconds: float = 1.2
var health: int = 5
var _hurt_wait: float = 0.0
var state: State = State.IDLE
var stamina: float = 100.0
var facing: Vector2 = Vector2.DOWN
var input_direction: Vector2 = Vector2.ZERO
var is_airborne: bool = false
var _exhausted: bool = false
var _regen_wait: float = 0.0
var _jump_time: float = 0.0
var _cooldown: float = 0.0
var _stun_time: float = 0.0
var _last_safe_ground: Vector2 = Vector2.ZERO
@onready var visual: Node2D = $VisualPivot
@onready var art: FarmerVisual = $VisualPivot/FarmerVisual
@onready var shadow: Polygon2D = $Shadow
@onready var ground_shape: CollisionShape2D = $GroundShape

func _ready() -> void:
    health = max_health
    health_changed.emit(health, max_health)
    stamina = max_stamina
    stamina_changed.emit(stamina, max_stamina)
    state_changed.emit(state_name())

func _physics_process(delta: float) -> void:
    _hurt_wait = maxf(0.0, _hurt_wait - delta)
    art.hurt = _hurt_wait > 0.0
    if health <= 0:
        velocity = Vector2.ZERO
        return
    _cooldown = maxf(0.0, _cooldown - delta)
    _regen_wait = maxf(0.0, _regen_wait - delta)
    _stun_time = maxf(0.0, _stun_time - delta)
    input_direction = Input.get_vector("move_left", "move_right", "move_up", "move_down")
    if _stun_time > 0.0:
        input_direction = Vector2.ZERO
    if input_direction != Vector2.ZERO:
        # Cuatro orientaciones visuales para ocho direcciones de movimiento.
        if absf(input_direction.x) > absf(input_direction.y):
            facing = Vector2(signf(input_direction.x), 0.0)
        else:
            facing = Vector2(0.0, signf(input_direction.y))
    if _stun_time <= 0.0 and Input.is_action_just_pressed("jump"):
        _try_jump()
    var wants_run: bool = Input.is_action_pressed("run") and input_direction != Vector2.ZERO
    var can_run: bool = wants_run and not _exhausted and stamina > 0.0 and _stun_time <= 0.0
    if can_run:
        stamina = maxf(0.0, stamina - run_drain * delta)
        _regen_wait = regeneration_delay
        if stamina <= 0.0:
            _exhausted = true
    elif _regen_wait <= 0.0 and _stun_time <= 0.0:
        var rate: float = rest_regeneration if input_direction == Vector2.ZERO else walk_regeneration
        stamina = minf(max_stamina, stamina + rate * delta)
    # Histéresis: no alternar correr/caminar cada frame al llegar a cero.
    if _exhausted and stamina >= max_stamina * 0.25:
        _exhausted = false
    var desired: State = State.IDLE
    if _stun_time > 0.0:
        desired = State.STUNNED
    elif input_direction != Vector2.ZERO:
        desired = State.RUNNING if can_run else State.WALKING
    _set_state(desired)
    var speed: float = run_speed if state == State.RUNNING else walk_speed
    velocity = velocity.move_toward(input_direction * speed, acceleration * delta)
    move_and_slide()
    _update_jump(delta)
    art.facing = facing
    art.moving = velocity.length() > 4.0
    art.running = state == State.RUNNING
    art.stunned = state == State.STUNNED
    stamina_changed.emit(stamina, max_stamina)

func _try_jump() -> void:
    if is_airborne or _cooldown > 0.0:
        return
    is_airborne = true
    _last_safe_ground = global_position
    _jump_time = 0.0
    set_collision_mask_value(LOW_OBSTACLE_LAYER, false)
    jump_changed.emit(true)

func _update_jump(delta: float) -> void:
    if not is_airborne:
        return
    if not _overlaps_low_obstacle():
        _last_safe_ground = global_position
    _jump_time += delta
    var progress: float = minf(_jump_time / maxf(0.01, jump_duration), 1.0)
    visual.position.y = roundf(-sin(progress * PI) * jump_height)
    shadow.scale = Vector2.ONE * (1.0 - sin(progress * PI) * 0.25)
    if progress >= 1.0:
        # Aterrizar sobre una raíz devuelve al último punto libre de la trayectoria.
        # Evita tanto introducir el cuerpo en una raíz como flotar indefinidamente.
        if _overlaps_low_obstacle():
            global_position = _last_safe_ground
            velocity = Vector2.ZERO
        is_airborne = false
        visual.position.y = 0.0
        shadow.scale = Vector2.ONE
        set_collision_mask_value(LOW_OBSTACLE_LAYER, true)
        _cooldown = jump_cooldown
        jump_changed.emit(false)

func _overlaps_low_obstacle() -> bool:
    var query := PhysicsShapeQueryParameters2D.new()
    query.shape = ground_shape.shape
    query.transform = ground_shape.global_transform
    query.collision_mask = 1 << (LOW_OBSTACLE_LAYER - 1)
    query.exclude = [get_rid()]
    return not get_world_2d().direct_space_state.intersect_shape(query, 1).is_empty()

func stun(seconds: float = 0.8) -> void:
    ## Punto de entrada para el gallo y depredadores en fases posteriores.
    _stun_time = maxf(_stun_time, seconds)
    _set_state(State.STUNNED)

func _set_state(next: State) -> void:
    if next != state:
        state = next
        state_changed.emit(state_name())

func state_name() -> String:
    return ["Idle", "Caminar", "Correr", "Aturdido"][state]

func take_damage(amount: int = 1) -> bool:
    ## El salto y la invulnerabilidad evitan daño; nunca se acumula contacto por frame.
    if amount <= 0 or health <= 0 or is_airborne or _hurt_wait > 0.0:
        return false
    health = maxi(0, health - amount)
    _hurt_wait = invulnerability_seconds
    stun(0.35)
    health_changed.emit(health, max_health)
    if health == 0:
        incapacitated.emit()
    return true
