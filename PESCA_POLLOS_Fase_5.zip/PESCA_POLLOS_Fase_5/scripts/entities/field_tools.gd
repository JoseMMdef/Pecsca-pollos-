extends Node
## Herramientas independientes del controlador de movimiento y del inventario.
signal feedback(message: String)
signal tools_changed(baits_left: int)
signal repair_progress(progress: float)
const TRAP_SCENE: PackedScene = preload("res://scenes/entities/trap.tscn")
@export var net_range: float = 80.0
@export var net_half_angle: float = 0.85
@export var net_hold_seconds: float = 2.8
@export var net_cooldown: float = 0.8
@export var baits: int = 3
@export var repair_range: float = 58.0
@onready var player: FarmerPlayer = get_parent()
var _net_wait: float = 0.0
var _net_flash: float = 0.0
var _repair_elapsed: float = 0.0
var _repair_target: FenceGap
var _placement_wait: float = 0.0

func _physics_process(delta: float) -> void:
    _net_wait = maxf(0.0, _net_wait - delta)
    _net_flash = maxf(0.0, _net_flash - delta)
    _placement_wait = maxf(0.0, _placement_wait - delta)
    player.art.net_active = _net_flash > 0.0
    if Input.is_action_just_pressed("net"):
        use_net()
    if Input.is_action_just_pressed("trap"):
        place_trap()
    _update_repair(delta)

func _can_act() -> bool:
    return player.state != FarmerPlayer.State.STUNNED and not player.is_airborne

func use_net() -> int:
    if not _can_act() or _net_wait > 0.0:
        return 0
    _net_wait = net_cooldown
    _net_flash = 0.2
    var hits: int = 0
    for node in get_tree().get_nodes_in_group("chickens"):
        var bird := node as FarmChicken
        if bird == null or bird.is_claimed or bird.is_trapped():
            continue
        var offset: Vector2 = bird.global_position - player.global_position
        if offset.length() > net_range:
            continue
        if offset.length() > 1.0 and player.facing.dot(offset.normalized()) < cos(net_half_angle):
            continue
        if not _clear_line(bird.global_position):
            continue
        if bird.apply_net(net_hold_seconds):
            hits += 1
    feedback.emit("Red: %d aves inmovilizadas. Acércate y pulsa E." % hits if hits > 0 else "La red no alcanzó aves al frente.")
    return hits

func place_trap() -> BaitTrap:
    if not _can_act() or _placement_wait > 0.0:
        return null
    _placement_wait = 0.25
    if baits <= 0:
        feedback.emit("Sin carnadas: tienes tres por partida.")
        return null
    var point: Vector2 = player.global_position + player.facing * 36.0
    if not can_place_at(point):
        feedback.emit("No puedes colocar carnada aquí: busca suelo libre.")
        return null
    var trap: BaitTrap = TRAP_SCENE.instantiate()
    trap.position = player.get_parent().to_local(point)
    player.get_parent().add_child(trap)
    baits -= 1
    tools_changed.emit(baits)
    feedback.emit("Carnada colocada: aléjate para que un ave tranquila se acerque.")
    return trap

func can_place_at(point: Vector2) -> bool:
    # Bloquear bordes, cuerpos del mundo, agua, raíces, corral y otras trampas.
    var farm: Node = player.get_tree().current_scene
    if farm == null or not Rect2(32, 32, 1216, 704).has_point(point):
        return false
    if not _clear_line(point):
        return false
    for crow in get_tree().get_nodes_in_group("scarecrows"):
        if crow.global_position.distance_to(point) < 32.0:
            return false
    var shape := CircleShape2D.new()
    shape.radius = 15.0
    var query := PhysicsShapeQueryParameters2D.new()
    query.shape = shape
    query.transform = Transform2D(0.0, point)
    query.collision_mask = 280 | 64 | 1024
    query.collide_with_areas = true
    return player.get_world_2d().direct_space_state.intersect_shape(query, 1).is_empty()

func _clear_line(point: Vector2) -> bool:
    var query := PhysicsRayQueryParameters2D.create(player.global_position, point, 280 | 512)
    return player.get_world_2d().direct_space_state.intersect_ray(query).is_empty()

func _update_repair(delta: float) -> void:
    var target: FenceGap = null
    if _can_act() and Input.is_action_pressed("repair"):
        var best: float = repair_range
        for node in get_tree().get_nodes_in_group("fence_gaps"):
            var gap := node as FenceGap
            if gap != null and not gap.repaired:
                var distance: float = player.global_position.distance_to(gap.global_position)
                if distance <= best:
                    target = gap
                    best = distance
    if target == null:
        if _repair_elapsed > 0.0:
            repair_progress.emit(0.0)
        _repair_target = null
        _repair_elapsed = 0.0
        return
    if _repair_target != target:
        _repair_elapsed = 0.0
        _repair_target = target
    _repair_elapsed += delta
    repair_progress.emit(minf(1.0, _repair_elapsed / maxf(0.01, target.repair_seconds)))
    if _repair_elapsed >= target.repair_seconds:
        if target.complete_repair():
            feedback.emit("Cerca reparada: fuga cerrada.")
            _repair_elapsed = 0.0
            repair_progress.emit(0.0)
        else:
            feedback.emit("Espera a que el hueco quede libre para terminar.")
