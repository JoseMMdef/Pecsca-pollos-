class_name ChickenSack
extends Node
## Inventario de datos, nunca de nodos: borrar una gallina no invalida el saco.
signal changed(count: int, capacity: int)
@export_range(1, 30) var capacity: int = 6
var _birds: Array[ChickenData] = []

func count() -> int:
    return _birds.size()

func try_add(data: ChickenData) -> bool:
    if data == null or _birds.size() >= capacity:
        return false
    _birds.append(data)
    changed.emit(count(), capacity)
    return true

func take_all() -> Array[ChickenData]:
    ## Entrega atómica: vaciar antes de emitir evita depósitos duplicados.
    var result: Array[ChickenData] = _birds.duplicate()
    _birds.clear()
    changed.emit(0, capacity)
    return result
