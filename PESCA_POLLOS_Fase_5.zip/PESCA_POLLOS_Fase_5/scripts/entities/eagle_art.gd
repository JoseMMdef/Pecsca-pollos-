extends Node2D
## Silueta nativa provisional, separada de su sombra de aviso en el suelo.
var _phase: float = 0.0
func _process(delta: float) -> void:
    _phase += delta * 10.0
    queue_redraw()
func _draw() -> void:
    var flap: float = 3.0 if sin(_phase) > 0.0 else -3.0
    draw_rect(Rect2(-4, -9, 8, 16), Color("614d3b"))
    draw_rect(Rect2(-22, -5+flap, 19, 6), Color("8e7759"))
    draw_rect(Rect2(3, -5+flap, 19, 6), Color("8e7759"))
    draw_rect(Rect2(-4, -12, 8, 6), Color("eee1bd"))
    draw_rect(Rect2(-2, -14, 4, 3), Color("d2a04a"))
