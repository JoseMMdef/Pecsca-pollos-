class_name BaitTrap
extends Area2D
## Una carnada retiene una única ave. E la embolsa; el saco no se llena a distancia.
enum State { READY, OCCUPIED, SPENT }
@export var lure_radius: float = 140.0
var state: State = State.READY
var held_bird: FarmChicken

func is_available() -> bool:
    return state == State.READY

func _physics_process(_delta: float) -> void:
    if state != State.READY:
        return
    for body in get_overlapping_bodies():
        if body is FarmChicken and body.try_hold(self):
            held_bird = body
            state = State.OCCUPIED
            body.captured.connect(_on_bird_captured, CONNECT_ONE_SHOT)
            body.lost.connect(_on_bird_lost, CONNECT_ONE_SHOT)
            queue_redraw()
            return

func _on_bird_captured(_data: ChickenData) -> void:
    state = State.SPENT
    queue_free()

func _exit_tree() -> void:
    # Si se retira una trampa por cambio de nivel, no dejar un ave bloqueada.
    if is_instance_valid(held_bird) and not held_bird.is_claimed:
        held_bird.release_from_trap(self)

func _draw() -> void:
    draw_rect(Rect2(-14, -9, 28, 18), Color("6d4932"))
    draw_rect(Rect2(-12, -7, 24, 14), Color("c49a5d"), false, 2.0)
    if state == State.READY:
        for point in [Vector2(-3, 0), Vector2(3, -2), Vector2(0, 3)]:
            draw_rect(Rect2(point, Vector2(3, 2)), Color("f4cf65"))
    else:
        draw_rect(Rect2(-13, -11, 26, 20), Color("e3c994"), false, 2.0)

func _on_bird_lost(_data: ChickenData, _cause: StringName) -> void:
    state = State.SPENT
    queue_free()
