class_name FarmScarecrow
extends Area2D
## Zona de exclusión aérea; no detiene zorros ni protege aves fuera del radio.
@export var safe_radius: float = 128.0
func _ready() -> void:
    var circle := CircleShape2D.new()
    circle.radius = safe_radius
    $Shape.shape = circle
    queue_redraw()
func protects(point: Vector2) -> bool:
    return global_position.distance_squared_to(point) <= safe_radius * safe_radius
func _draw() -> void:
    draw_circle(Vector2.ZERO, safe_radius, Color(0.4, 0.85, 0.72, 0.08))
    draw_arc(Vector2.ZERO, safe_radius, 0.0, TAU, 64, Color(0.5, 0.9, 0.7, 0.4), 1.0)
    draw_rect(Rect2(-2, -31, 4, 33), Color("916237"))
    draw_rect(Rect2(-21, -25, 42, 4), Color("ba975a"))
    draw_rect(Rect2(-9, -30, 18, 18), Color("ab5c3f"))
    draw_rect(Rect2(-7, -43, 14, 13), Color("deb36b"))
    draw_rect(Rect2(-12, -43, 24, 3), Color("755032"))
    draw_rect(Rect2(-7, -49, 14, 7), Color("ab8545"))
