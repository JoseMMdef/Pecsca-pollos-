class_name FenceGap
extends Area2D
## Hueco real de la cerca sur. Un bloqueo exclusivo del jugador mantiene el mapa cerrado.
signal repaired_changed(repaired: bool)
@export var repair_seconds: float = 1.2
@export var escape_line_y: float = 0.0
var repaired: bool = false

func _physics_process(_delta: float) -> void:
    if repaired:
        return
    for body in get_overlapping_bodies():
        if body is FarmChicken and body.global_position.y >= global_position.y + escape_line_y:
            if body.state == FarmChicken.State.ALERT:
                body.try_escape()

func complete_repair() -> bool:
    if repaired:
        return false
    # No sellar la cerca sobre un cuerpo. El jugador ya tiene su barrera exclusiva.
    var query := PhysicsShapeQueryParameters2D.new()
    query.shape = $RepairedFence/Shape.shape
    query.transform = $RepairedFence/Shape.global_transform
    query.collision_mask = 3
    if not get_world_2d().direct_space_state.intersect_shape(query, 1).is_empty():
        return false
    repaired = true
    $RepairedFence.set_deferred("collision_layer", 8)
    repaired_changed.emit(true)
    queue_redraw()
    return true

func _draw() -> void:
    draw_rect(Rect2(-32, -9, 64, 18), Color("65442f") if repaired else Color("30251f"))
    if repaired:
        draw_rect(Rect2(-32, -6, 64, 4), Color("bc8a50"))
        draw_rect(Rect2(-32, 3, 64, 4), Color("a07040"))
        for x in [-30, 28]:
            draw_rect(Rect2(x, -14, 4, 28), Color("d1a366"))
    else:
        draw_line(Vector2(-30, -10), Vector2(-19, 8), Color("bc8a50"), 4.0)
        draw_line(Vector2(30, -10), Vector2(20, 7), Color("bc8a50"), 4.0)
