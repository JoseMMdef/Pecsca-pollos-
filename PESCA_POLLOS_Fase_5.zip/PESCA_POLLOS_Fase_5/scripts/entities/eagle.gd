class_name FarmEagle
extends CharacterBody2D
## Vuelo sin colisión de mundo; la sombra avisa antes de una picada vulnerable.
signal defeated
signal warning(point: Vector2)
enum State { CRUISE, WARNING, DIVE, RETREAT }
@export var warning_seconds: float = 1.4
@export var dive_seconds: float = 0.55
@export var flight_speed: float = 150.0
var state: State = State.CRUISE
var _time: float = 0.7
var _target: FarmChicken
var _strike_point: Vector2 = Vector2.ZERO
var _height: float = 100.0
var _phase: float = 0.0
var _gone: bool = false

func _physics_process(delta: float) -> void:
    _phase += delta * 9.0
    _time -= delta
    match state:
        State.CRUISE:
            if not is_instance_valid(_target) or _target.is_claimed or _is_protected(_target.global_position):
                _target = _choose_target()
            if is_instance_valid(_target):
                global_position = global_position.move_toward(_target.global_position, flight_speed * delta)
                if _time <= 0.0 and global_position.distance_to(_target.global_position) < 20.0:
                    begin_warning(_target)
            elif _time < -5.0:
                retreat()
        State.WARNING:
            # El punto de ataque queda fijado: es posible salvar un ave antes de la picada.
            if not is_instance_valid(_target) or _target.is_claimed or _is_protected(_strike_point) or _is_protected(_target.global_position):
                retreat()
            elif _time <= 0.0:
                state = State.DIVE
                _time = dive_seconds
        State.DIVE:
            if _is_protected(_strike_point) or (is_instance_valid(_target) and _is_protected(_target.global_position)):
                retreat()
            else:
                # Picada rápida con seguimiento: la sombra anuncia el ataque, no una
                # inmunidad automática por caminar fuera del punto inicial.
                if is_instance_valid(_target) and not _target.is_claimed:
                    global_position = global_position.move_toward(_target.global_position, flight_speed * 3.0 * delta)
                    _strike_point = global_position
                _height = 100.0 * clampf(_time / maxf(0.01, dive_seconds), 0.0, 1.0)
                if _time <= 0.0:
                    _strike()
        State.RETREAT:
            _height += delta * 180.0
            if _time <= 0.0:
                _remove()
    $Shadow.visible = state == State.WARNING or state == State.DIVE
    $Art.position.y = -roundf(_height)
    queue_redraw()
    $Art.queue_redraw()

func _choose_target() -> FarmChicken:
    var selected: FarmChicken = null
    var nearest: float = INF
    for node in get_tree().get_nodes_in_group("chickens"):
        var bird := node as FarmChicken
        if bird == null or bird.is_claimed or _is_protected(bird.global_position):
            continue
        var distance: float = global_position.distance_squared_to(bird.global_position)
        if distance < nearest:
            nearest = distance
            selected = bird
    return selected

func _is_protected(point: Vector2) -> bool:
    for node in get_tree().get_nodes_in_group("scarecrows"):
        if node.protects(point):
            return true
    return false

func begin_warning(bird: FarmChicken) -> bool:
    if bird == null or bird.is_claimed or _is_protected(bird.global_position):
        return false
    _target = bird
    _strike_point = bird.global_position
    global_position = _strike_point
    _height = 100.0
    state = State.WARNING
    _time = warning_seconds
    warning.emit(_strike_point)
    return true

func _strike() -> void:
    if not _is_protected(_strike_point):
        if is_instance_valid(_target) and not _target.is_claimed:
            if _target.global_position.distance_to(_strike_point) < 28.0:
                _target.try_predation(&"eagle")
        for node in get_tree().get_nodes_in_group("player"):
            if node.global_position.distance_to(_strike_point) < 22.0:
                node.take_damage(1)
    retreat()

func receive_shot() -> bool:
    if state != State.DIVE or _gone:
        return false
    defeated.emit()
    _remove()
    return true

func retreat() -> void:
    if state == State.RETREAT:
        return
    state = State.RETREAT
    _time = 0.7

func _remove() -> void:
    if _gone:
        return
    _gone = true
    remove_from_group("predators")
    remove_from_group("eagles")
    hide()
    queue_free()
