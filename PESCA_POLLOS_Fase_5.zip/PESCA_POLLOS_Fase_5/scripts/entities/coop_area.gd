extends Area2D
## Descarga tanto al entrar como al capturar permaneciendo dentro de la zona.
signal deposited(count: int, value: int)

func _physics_process(_delta: float) -> void:
    for body in get_overlapping_bodies():
        if body is FarmerPlayer:
            deposit_from(body.get_node("Sack") as ChickenSack)

func deposit_from(sack: ChickenSack) -> void:
    if sack == null or sack.count() == 0:
        return
    var birds: Array[ChickenData] = sack.take_all()
    var value: int = 0
    for bird in birds:
        value += bird.reward
    deposited.emit(birds.size(), value)
    EventBus.chicken_deposited.emit(birds.size(), value)
