class_name FarmerVisual
extends Node2D
## Sustituto visual nativo y reemplazable: dibujo a píxel, sin arte externo.
## No es una hoja recuperada del tileset. El cuerpo físico no depende de este nodo.
var facing: Vector2 = Vector2.DOWN
var moving: bool = false
var running: bool = false
var stunned: bool = false
var capturing: bool = false
var net_active: bool = false
var hurt: bool = false
var _clock: float = 0.0

func _process(delta: float) -> void:
    _clock += delta * (15.0 if running else 10.0)
    queue_redraw()

func _block(x: float, y: float, w: float, h: float, color: Color) -> void:
    draw_rect(Rect2(x, y, w, h), color)

func _draw() -> void:
    var step: float = (1.0 if sin(_clock) > 0.0 else -1.0) if moving else 0.0
    var dark := Color("302c36")
    var skin := Color("edb57b")
    var shirt := Color("e3ad50")
    var blue := Color("365e9c")
    modulate = Color("ffc2b2") if (stunned or hurt) and int(_clock * 2.0) % 2 == 0 else Color.WHITE
    _block(-6, -10, 12, 9, dark)
    _block(-5, -9, 4, 6 + step, blue)
    _block(1, -9, 4, 6 - step, blue)
    _block(-6, -3 + step, 5, 3, dark)
    _block(1, -3 - step, 5, 3, dark)
    _block(-8, -19, 16, 12, dark)
    _block(-7, -18, 14, 10, shirt)
    _block(-9, -16 + step, 3, 7, skin)
    _block(6, -16 - step, 3, 7, skin)
    _block(-5, -15, 10, 8, blue)
    _block(-5, -18, 2, 6, blue)
    _block(3, -18, 2, 6, blue)
    _block(-6, -27, 12, 11, dark)
    _block(-5, -26, 10, 9, skin)
    if facing == Vector2.UP:
        _block(-5, -26, 10, 9, Color("765036"))
    elif facing.x == 0.0:
        _block(-3, -22, 2, 2, dark)
        _block(2, -22, 2, 2, dark)
    else:
        _block(2 if facing.x > 0 else -4, -22, 2, 2, dark)
        _block(5 if facing.x > 0 else -7, -21, 2, 3, skin)
    _block(-11, -29, 22, 4, dark)
    _block(-10, -29, 20, 3, Color("cf9645"))
    _block(-7, -34, 14, 6, dark)
    _block(-6, -33, 12, 5, Color("e4bb61"))
    _block(-6, -29, 12, 2, Color("a46435"))
    if stunned:
        _block(-2, -40, 4, 3, Color("ffe78f"))
    if capturing:
        draw_arc(Vector2(0, -12), 20.0, -0.8, 2.8, 12, Color("fff0ac"), 2.0)
    if net_active:
        var center: Vector2 = facing * 28.0 + Vector2(0, -12)
        draw_line(Vector2(0, -12), center, Color("d5a968"), 2.0)
        draw_arc(center, 12.0, 0.0, TAU, 16, Color("a0e1df"), 2.0)
