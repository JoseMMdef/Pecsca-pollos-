class_name FarmFox
extends CharacterBody2D
## Cazador terrestre: elige concentraciones, patrulla lindes y respeta obstáculos.
signal defeated
@export var speed: float = 104.0
@export var steal_distance: float = 17.0
var _patrol_index: int = 0
var _retarget: float = 0.0
var _target: FarmChicken
var _gone: bool = false
var _phase: float = 0.0
var bounds: Rect2 = Rect2(32, 32, 1216, 704)

func _physics_process(delta: float) -> void:
    if _gone:
        return
    _phase += delta * 10.0
    _retarget -= delta
    if _retarget <= 0.0 or not is_instance_valid(_target) or _target.is_claimed:
        _retarget = 0.5
        _target = _select_cluster()
    var destination: Vector2
    if is_instance_valid(_target):
        destination = _target.global_position
        if global_position.distance_to(destination) <= steal_distance and _has_sight(destination):
            if _target.try_predation(&"fox"):
                retreat()
                return
    else:
        var points: Array[Vector2] = [bounds.position + Vector2(32,32), Vector2(bounds.end.x-32,bounds.position.y+32), bounds.end-Vector2(32,32), Vector2(bounds.position.x+32,bounds.end.y-32)]
        destination = points[_patrol_index]
        if global_position.distance_to(destination) < 20.0:
            _patrol_index = (_patrol_index + 1) % points.size()
    velocity = _steer(global_position.direction_to(destination)) * speed
    move_and_slide()
    for node in get_tree().get_nodes_in_group("player"):
        var player := node as FarmerPlayer
        if player != null and global_position.distance_to(player.global_position) < 19.0 and _has_sight(player.global_position):
            player.take_damage(1)
    queue_redraw()

func _select_cluster() -> FarmChicken:
    var birds: Array[Node] = get_tree().get_nodes_in_group("chickens")
    var chosen: FarmChicken = null
    var score: float = -INF
    for node in birds:
        var bird := node as FarmChicken
        if bird == null or bird.is_claimed:
            continue
        var nearby: int = 0
        for other in birds:
            if bird.global_position.distance_squared_to(other.global_position) < 19600.0:
                nearby += 1
        var candidate: float = nearby * 120.0 - global_position.distance_to(bird.global_position)
        if candidate > score:
            score = candidate
            chosen = bird
    return chosen

func _steer(direction: Vector2) -> Vector2:
    for angle: float in [0.0, 0.65, -0.65, 1.3, -1.3, PI]:
        var trial: Vector2 = direction.rotated(angle)
        var ray := PhysicsRayQueryParameters2D.create(global_position, global_position + trial * 28.0, 280)
        if get_world_2d().direct_space_state.intersect_ray(ray).is_empty():
            return trial
    return Vector2.ZERO

func receive_shot() -> bool:
    if _gone:
        return false
    retreat()
    defeated.emit()
    return true

func retreat() -> void:
    _gone = true
    remove_from_group("predators")
    remove_from_group("foxes")
    hide()
    queue_free()

func _draw() -> void:
    var facing: float = -1.0 if velocity.x < 0.0 else 1.0
    draw_rect(Rect2(-12, -8, 20, 9), Color("a84926"))
    draw_rect(Rect2(-11, -11, 19, 9), Color("dc7533"))
    draw_rect(Rect2(7*facing-5, -15, 10, 10), Color("dc7533"))
    draw_rect(Rect2(8*facing-3, -18, 4, 5), Color("5e342b"))
    draw_rect(Rect2(10*facing-2, -11, 3, 2), Color("242331"))
    draw_rect(Rect2(-18*facing-4, -8, 10, 5), Color("f0d8ad"))
    var step: float = 2.0 if sin(_phase) > 0.0 else 0.0
    draw_rect(Rect2(-8, -2, 4, 4+step), Color("45342e"))
    draw_rect(Rect2(4, -2, 4, 6-step), Color("45342e"))

func _has_sight(point: Vector2) -> bool:
    var query := PhysicsRayQueryParameters2D.create(global_position, point, 280)
    return get_world_2d().direct_space_state.intersect_ray(query).is_empty()
