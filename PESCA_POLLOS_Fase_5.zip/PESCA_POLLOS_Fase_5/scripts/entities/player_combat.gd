extends Node
## Escopeta y colocación de espantapájaros. Una carga de munición genera tres perdigones.
signal changed(ammo: int, scarecrows: int)
signal feedback(message: String)
const BULLET: PackedScene = preload("res://scenes/entities/bullet.tscn")
const CROW: PackedScene = preload("res://scenes/entities/scarecrow.tscn")
var ammunition: int = 8
var scarecrows: int = 2
var _shot_wait: float = 0.0
@onready var player: FarmerPlayer = get_parent()

func configure(data: LevelData) -> void:
    ammunition = data.ammunition
    scarecrows = data.scarecrow_supply
    changed.emit(ammunition, scarecrows)

func _physics_process(delta: float) -> void:
    _shot_wait = maxf(0.0, _shot_wait - delta)
    if Input.is_action_just_pressed("shoot"):
        shoot()
    if Input.is_action_just_pressed("scarecrow"):
        place_scarecrow()

func _can_act() -> bool:
    return player.health > 0 and player.state != FarmerPlayer.State.STUNNED and not player.is_airborne

func shoot() -> bool:
    if not _can_act() or _shot_wait > 0.0:
        return false
    if ammunition <= 0:
        feedback.emit("Sin munición: usa el salto y protege las aves.")
        return false
    ammunition -= 1
    _shot_wait = 0.65
    for angle: float in [-0.12, 0.0, 0.12]:
        var bullet: Node2D = BULLET.instantiate()
        bullet.position = player.get_parent().to_local(player.global_position)
        bullet.direction = player.facing.rotated(angle)
        player.get_parent().add_child(bullet)
    changed.emit(ammunition, scarecrows)
    feedback.emit("Disparo: apunta al frente. Águilas vulnerables durante la picada.")
    return true

func place_scarecrow() -> FarmScarecrow:
    if not _can_act() or scarecrows <= 0:
        feedback.emit("No puedes colocar otro espantapájaros ahora.")
        return null
    var point: Vector2 = player.global_position + player.facing * 36.0
    if not player.get_node("FieldTools").can_place_at(point):
        feedback.emit("Espantapájaros: busca suelo libre.")
        return null
    var crow: FarmScarecrow = CROW.instantiate()
    crow.position = player.get_parent().to_local(point)
    player.get_parent().add_child(crow)
    scarecrows -= 1
    changed.emit(ammunition, scarecrows)
    feedback.emit("Espantapájaros colocado: su círculo bloquea picadas.")
    return crow
