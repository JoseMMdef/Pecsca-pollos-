class_name ChickenData
extends Resource
## Datos compartidos inmutables durante una ronda; el estado pertenece al pollo.
@export var id: StringName = &"standard"
@export_range(1.0, 300.0) var calm_speed: float = 22.0
@export_range(1.0, 500.0) var flee_speed: float = 75.0
@export_range(1, 1000) var reward: int = 10
@export_range(0.0, 1.0) var aggression: float = 0.0
@export var tint: Color = Color.WHITE
