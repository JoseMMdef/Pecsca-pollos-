class_name LevelData
extends Resource
## Configuración editable. No almacena contadores de una partida.
enum GoalMode { BIRDS, MONEY, EITHER }
@export var title: String = "La Granja"
@export var goal_mode: GoalMode = GoalMode.BIRDS
@export_range(1, 1000) var bird_quota: int = 8
@export_range(1, 100000) var money_goal: int = 100
@export_range(1.0, 3600.0) var round_seconds: float = 180.0
@export var chicken_types: Array[ChickenData] = []
## Las cantidades corresponden por índice a chicken_types.
@export var chicken_counts: Array[int] = []
@export_range(1.0, 600.0) var fox_interval: float = 30.0
@export_range(1.0, 600.0) var eagle_interval: float = 60.0
@export_range(0, 100) var ammunition: int = 8
@export_group("Depredadores")
@export var predators_enabled: bool = true
@export_range(1.0, 300.0) var first_fox_seconds: float = 12.0
@export_range(1.0, 300.0) var first_eagle_seconds: float = 25.0
@export_range(1, 5) var fox_pack_size: int = 2
@export_range(1, 5) var eagle_flock_size: int = 2
@export_range(1, 12) var max_foxes: int = 4
@export_range(1, 12) var max_eagles: int = 4
@export_range(0, 10) var scarecrow_supply: int = 2
@export var map_cells: Vector2i = Vector2i(40, 24)

func validation_errors() -> PackedStringArray:
    var errors := PackedStringArray()
    if chicken_types.size() != chicken_counts.size():
        errors.append("Cada tipo requiere una cantidad.")
    for bird_type in chicken_types:
        if bird_type == null:
            errors.append("No se permiten tipos de pollo vacíos.")
    if round_seconds <= 0.0 or fox_interval <= 0.0 or eagle_interval <= 0.0:
        errors.append("Tiempos e intervalos deben ser positivos.")
    for count in chicken_counts:
        if count < 0:
            errors.append("Las cantidades no pueden ser negativas.")
    return errors
