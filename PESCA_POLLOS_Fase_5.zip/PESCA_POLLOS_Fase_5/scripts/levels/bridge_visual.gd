extends Node2D
## Tablones y barandas son decoración nativa sobre el TileMapLayer Bridge.
## La superficie queda libre; las barandas tienen cuerpos independientes.
func _draw() -> void:
    draw_rect(Rect2(0, 0, 64, 224), Color("533828"))
    for y in range(0, 224, 8):
        draw_rect(Rect2(3, y + 1, 58, 6), Color("b5844c"))
        draw_line(Vector2(8, y + 2), Vector2(54, y + 2), Color("cba466"))
    draw_rect(Rect2(-3, 0, 5, 224), Color("735136"))
    draw_rect(Rect2(62, 0, 5, 224), Color("735136"))
