extends Node2D
## Obstáculo bajo: el salto desactiva solamente la máscara 9.
func _draw() -> void:
    draw_rect(Rect2(-24, -5, 48, 9), Color("563b2a"))
    draw_rect(Rect2(-22, -5, 44, 3), Color("ae8650"))
    draw_rect(Rect2(-14, -8, 7, 5), Color("765336"))
    draw_rect(Rect2(12, 2, 8, 5), Color("765336"))
