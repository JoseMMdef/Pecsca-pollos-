@tool
extends Node2D
## Pintado reproducible con semilla fija. @tool permite revisar capas en el editor.
## Las colisiones son nodos explícitos de la escena, no dependen de este pintado.
const TILESET: TileSet = preload("res://resources/tilesets/farm_tileset.tres")
const WIDTH: int = 40
const HEIGHT: int = 24

func _ready() -> void:
    var ground: TileMapLayer = $Ground
    var paths: TileMapLayer = $Paths
    var water: TileMapLayer = $Water
    var bridge: TileMapLayer = $Bridge
    for layer: TileMapLayer in [ground, paths, water, bridge]:
        layer.tile_set = TILESET
        layer.clear()
    var rng := RandomNumberGenerator.new()
    rng.seed = 9127
    for y in range(HEIGHT):
        for x in range(WIDTH):
            ground.set_cell(Vector2i(x, y), 0, Vector2i(rng.randi_range(0, 3), 0))
            if x in [18, 19] or y in [11, 12]:
                paths.set_cell(Vector2i(x, y), 0, Vector2i(4, 0))
    for y in range(14, 21):
        for x in range(24, 35):
            water.set_cell(Vector2i(x, y), 0, Vector2i(0, 1))
    # Puente de dos tiles de ancho. No hay cuerpo Water bajo estas columnas.
    for y in range(14, 21):
        for x in [28, 29]:
            bridge.set_cell(Vector2i(x, y), 0, Vector2i(5, 0))
