extends Node2D
## Spawner basado en LevelData. Puntos explícitos y comprobados fuera de obstáculos.
@export var level_data: LevelData
const BIRD_SCENE: PackedScene = preload("res://scenes/entities/chicken.tscn")
const POINTS: Array[Vector2] = [
    Vector2(650, 425), Vector2(720, 450), Vector2(520, 430),
    Vector2(420, 430), Vector2(350, 380), Vector2(220, 470),
    Vector2(880, 390), Vector2(1000, 380), Vector2(1050, 710),
    Vector2(720, 620), Vector2(540, 620), Vector2(350, 670)]

func _ready() -> void:
    if level_data == null:
        level_data = load("res://resources/levels/farm.tres")
    assert(level_data.validation_errors().is_empty(), "LevelData inválido")
    get_tree().paused = false
    GameManager.current_level = level_data
    if not GameManager.finished.is_connected(_on_finished):
        GameManager.finished.connect(_on_finished)
    $Depth/Player.health_changed.connect(_on_health_changed)
    GameManager.reset_round()
    $Depth/Player/PlayerCombat.configure(level_data)
    $ThreatDirector.start(level_data)
    $ThreatDirector.alert.connect($HUD._on_feedback)
    var index: int = 0
    for kind in range(level_data.chicken_types.size()):
        for amount in range(level_data.chicken_counts[kind]):
            assert(index < POINTS.size(), "Faltan puntos de aparición para LevelData")
            var bird: FarmChicken = BIRD_SCENE.instantiate()
            bird.data = level_data.chicken_types[kind]
            bird.position = POINTS[index]
            bird.escaped.connect(_on_bird_escaped)
            bird.lost.connect(_on_bird_lost)
            $Depth.add_child(bird)
            index += 1

func _on_bird_escaped(data: ChickenData) -> void:
    EventBus.chicken_lost.emit(data.reward)

func _on_bird_lost(data: ChickenData, _cause: StringName) -> void:
    EventBus.chicken_lost.emit(data.reward)

func _on_health_changed(current: int, _maximum: int) -> void:
    EventBus.player_health_changed.emit(current)

func _on_finished(won: bool, reason: String) -> void:
    $ResultOverlay.show_result(won, reason)
    get_tree().paused = true
