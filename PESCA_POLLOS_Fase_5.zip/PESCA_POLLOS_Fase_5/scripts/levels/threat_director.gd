extends Node
## Spawner de oleadas, independiente de la IA de cada depredador.
signal alert(message: String)
const FOX: PackedScene = preload("res://scenes/entities/fox.tscn")
const EAGLE: PackedScene = preload("res://scenes/entities/eagle.tscn")
var enabled: bool = true
var data: LevelData
var _fox_wait: float = 12.0
var _eagle_wait: float = 25.0
var _spawn_index: int = 0

func start(level: LevelData) -> void:
    data = level
    enabled = level.predators_enabled
    _fox_wait = level.first_fox_seconds
    _eagle_wait = level.first_eagle_seconds

func _physics_process(delta: float) -> void:
    if not enabled or data == null:
        return
    _fox_wait -= delta
    _eagle_wait -= delta
    if _fox_wait <= 0.0:
        spawn_fox_wave(data.fox_pack_size)
        _fox_wait = data.fox_interval
    if _eagle_wait <= 0.0:
        spawn_eagle_wave(data.eagle_flock_size)
        _eagle_wait = data.eagle_interval

func spawn_fox_wave(count: int) -> int:
    var spawned: int = 0
    var points: Array[Vector2] = [Vector2(64,96), Vector2(1190,640), Vector2(1180,96), Vector2(224,700)]
    for i in range(count):
        if get_tree().get_nodes_in_group("foxes").size() >= data.max_foxes:
            break
        var fox: FarmFox = FOX.instantiate()
        fox.position = points[_spawn_index % points.size()]
        fox.bounds = Rect2(Vector2(32,32), Vector2(data.map_cells * 32) - Vector2(64,64))
        get_parent().get_node("Depth").add_child(fox)
        _spawn_index += 1
        spawned += 1
    if spawned > 0:
        alert.emit("¡Zorros en las lindes! F: disparar hacia donde miras.")
    return spawned

func spawn_eagle_wave(count: int) -> int:
    var spawned: int = 0
    for i in range(count):
        if get_tree().get_nodes_in_group("eagles").size() >= data.max_eagles:
            break
        var eagle: FarmEagle = EAGLE.instantiate()
        eagle.position = Vector2(700 + i*64, 96)
        eagle.warning.connect(_on_warning)
        get_parent().get_node("Depth").add_child(eagle)
        spawned += 1
    if spawned > 0:
        alert.emit("¡Águilas! Vigila las sombras. R: espantapájaros.")
    return spawned

func _on_warning(_point: Vector2) -> void:
    alert.emit("¡Picada anunciada! Salva el ave o dispara durante el descenso.")
